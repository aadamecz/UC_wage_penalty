*Descriptive graphs and tables

cap log close 
log using "logs\5_OAR_wage_paper_descriptives", replace


************************************
*Histograms of main variables
************************************

use "$data\OAR_wage_paper_database_FTemployed.dta", clear

*Figure A1, left panel
twoway (histogram cognitive_cfa if female==1, color(gs12%30)) ///        
       (histogram cognitive_cfa if female==0,  color(gs4%30)), ///   
       legend(order(1 "Female" 2 "Male" ))  graphregion(color(white)) ///
	   xtitle("Objective abilities") title("Objective abilities")
graph export "figures\FigureA1_cognitive_dist.png" , as(png) replace

*Figure A1, right panel
twoway (histogram conf_irt if female==1, color(gs12%30)) ///        
       (histogram conf_irt if female==0,  color(gs4%30)), ///   
       legend(order(1 "Female" 2 "Male" ))  graphregion(color(white)) ///
	   xtitle("Self-assessed abilities") title("Self-assessed abilities")
graph export "figures\FigureA1_selfconcept_dist.png" , as(png) replace
	   
*Figure A2
twoway (histogram overconfidence_score if female==1, color(gs12%30)) ///        
       (histogram overconfidence_score if female==0,  color(gs4%30)), ///   
       legend(order(1 "Female" 2 "Male" ))  graphregion(color(white)) ///
	   xtitle("Overconfidence score") xlabel(-3(1)3) title("${title`j'}")
graph export "figures\FigureA2_overconfidence_dist.png" , as(png) replace


************************************
*The gender gap in wages and overconfidence
************************************

use "$data\OAR_wage_paper_database_FTemployed.dta", clear

global list log_hourlypay_42 overconfidence_score conf_irt underconfident overconfident
keep cog_rank female $list
collapse $list , by(cog_rank female)

*Figure 1, left and right panel
global titlelog_hourlypay_42 "Log hourly wage"
global titleoverconfidence_score "Overconfidence score"

global list log_hourlypay_42 overconfidence_score

foreach item in $list {
twoway (scatter `item' cog_rank if female==1, color(red)) ///
(lfit `item' cog_rank if female==1, color(red))  ///
(scatter `item' cog_rank if female==0,  color(blue))  ///
(lfit `item' cog_rank if female==0,  color(blue)), ///   
legend(order(1 "Female" 3 "Male" ))  graphregion(color(white)) ///
xtitle("Percentiles of objective cognitive ability") title("${title`item'}")

graph export "figures\Figure1_`item'.png" , as(png) replace
}

**********************************
*Figure A3, left and right panel
**********************************
global titleconf_irt "Self-assessed ability"
global titleunderconfident "Underconfident"
global titleoverconfident "Overconfident"

global list conf_irt underconfident overconfident

foreach item in $list {
twoway (scatter `item' cog_rank if female==1, color(red)) ///
(lfit `item' cog_rank if female==1, color(red))  ///
(scatter `item' cog_rank if female==0,  color(blue))  ///
(lfit `item' cog_rank if female==0,  color(blue)), ///   
legend(order(1 "Female" 3 "Male" ))  graphregion(color(white)) ///
xtitle("Percentiles of objective cognitive ability") title("${title`item'}")

graph export "figures\FigureA3_`item'.png" , as(png) replace
}


************************
*Table A3 - t-tests by gender
*************************
use "$data\OAR_wage_paper_database_FTemployed.dta", clear

global list log_hourlypay_42 hourlypay_42 ///
 cognitive_cfa conf_irt overconfidence_score overconfident underconfident ///
ethn1 ethn2 ethn3 ethn4 ethn5 ethn6 ethn7 ethn8 ///
reg1 reg2 reg3 reg4 reg5 reg6 reg7 reg8 reg9 reg10 reg11 reg12 ///
m_quali SES  ///
mathO1 mathO2 mathO3 mathO4 mathO5 mathO6 mathO7 mathO8 A_level ///
private_grammar STEM LEM other elite_uni  ///  
SOC2000_2digit private_sector emp_42  ///
partner_age42 children_age42 


estpost sum $list
esttab using "results\TableA3_descriptives.csv", replace ///
cells("mean(fmt(%13.2fc)) sd(fmt(%13.2fc)) min(fmt(%13.2fc)) max(fmt(%13.2fc))") nonumber  f ///
nomtitle nonote  label collabels("Mean" "SD" "Min" "Max")


estpost ttest $list , by(female)
esttab using "results\TableA4_ttests.csv", replace ///
cells("mu_1(fmt(%13.2fc)) mu_2(fmt(%13.2fc)) b(fmt(%13.2fc)) p(fmt(%13.2fc))") nonumber  f ///
nomtitle nonote  label collabels("Mean male" "Mean female" "Diff" "t-test p-value")

********************
*Short table for presentation
********************
global list log_hourlypay_42 hourlypay_42 cognitive_cfa conf_irt overconfidence_score overconfident underconfident graduate_age42   ///
partner_age42 children_age42 

*ttest by female
estpost ttest $list , by(female) 
esttab using "results\shortdesc_ttest.tex", replace ///
cells("mu_1(fmt(%13.2fc)) mu_2(fmt(%13.2fc)) b(fmt(%13.2fc)) p(fmt(%13.2fc))") nonumber  f ///
nomtitle nonote  label collabels("Mean male" "Mean female" "Diff" "t-test p-value")


cap log close