***************************-
*OAXACA
**************************
cap log close 
log using "logs\8_OAR_wage_paper_oaxaca", replace

use "$data\OAR_wage_paper_database_FTemployed.dta", clear

global outcome log_hourlypay_42

global controls0 i.region SES m_quali i.ethnicity 
global channels1 $controls0 i.private_grammar i.math_O_CSE i.A_level
global channels2 $channels1 STEM LEM other elite_uni 
global channels3 $channels2 i.SOC2000_2digit i.private_sector emp_42
global channels4 $channels3 partner_age42  child2 child3

*Constructing aggregates
global back _Iregion_2 _Iregion_3 _Iregion_4 _Iregion_5 _Iregion_6 _Iregion_7 _Iregion_8 _Iregion_9 _Iregion_10 _Iregion_11 _Iregion_99 _Iethnicity_2 _Iethnicity_3 _Iethnicity_4 _Iethnicity_5 _Iethnicity_6 _Iethnicity_7 _Iethnicity_8 _Iethnicity_99 SES m_quali

global educ _Iprivate_g_1 _Iprivate_g_99 _Imath_O_CS_1 _Imath_O_CS_2 _Imath_O_CS_3 _Imath_O_CS_4 _Imath_O_CS_5 _Imath_O_CS_6 _Imath_O_CS_99 _IA_level_1

global soc  _ISOC2000_2_12 _ISOC2000_2_21 _ISOC2000_2_22 _ISOC2000_2_23 _ISOC2000_2_24 _ISOC2000_2_31 _ISOC2000_2_32 _ISOC2000_2_33 _ISOC2000_2_34 _ISOC2000_2_35 _ISOC2000_2_41 _ISOC2000_2_42 _ISOC2000_2_51 _ISOC2000_2_52 _ISOC2000_2_53 _ISOC2000_2_54 _ISOC2000_2_61 _ISOC2000_2_62 _ISOC2000_2_71 _ISOC2000_2_72 _ISOC2000_2_81 _ISOC2000_2_82 _ISOC2000_2_91 _ISOC2000_2_92 _ISOC2000_2_99


*Oaxaca by gender
global detail "Background: $back , Education: $educ, Occupation: $soc"

xi: oaxaca $outcome underconfident overconfident cognitive_cfa $channels4  , by(female) pool detail detail($detail ) relax
outreg2 using "results\oaxaca_bygender.txt", replace bdec(3) sdec(3) noparen  sideway stats(coef se) noaster 

***********
*Figure 3
***********
import delimited  "results\oaxaca_bygender.txt",  rowrange(4:23) clear


replace v4=v2 if v4=="" | v4=="."
replace v5=v3 if v5=="" | v5=="."


drop v2 v3 v6 v7
drop if v1=="overall" | v1=="group_1" | v1=="group_2" | v1=="unexplained" 

rename v4 beta
rename v5 se

destring beta , replace
destring se , replace

gsort -beta

/*
v1	beta	se
difference	.181	.015
explained	.089	.012
emp_42	.034	.005
Occupation	.033	.008
STEM	.012	.003
child3	.008	.002
_Iprivate_s_1	.007	.003
underconfident	.005	.002
cognitive_cfa	.003	.001
Education	.003	.002
partner_age42	.002	.002
Background	.002	.002
elite_uni	0	.001
overconfident	-.001	.001
child2	-.002	.001
LEM	-.005	.002
other	-.012	.003
*/

gen sor=1 if v1=="difference"
replace sor=2 if v1=="explained"
replace sor=3 if v1=="emp_42"
replace sor=4 if v1=="Occupation"
replace sor=5 if v1=="STEM"
replace sor=6 if v1=="child3"
replace sor=7 if v1=="_Iprivate_s_1"
replace sor=8 if v1=="underconfident"
replace sor=9 if v1=="cognitive_cfa"
replace sor=10 if v1=="Education"
replace sor=11 if v1=="partner_age42"
replace sor=12 if v1=="Background"
replace sor=13 if v1=="elite_uni"
replace sor=14 if v1=="overconfident"
replace sor=15 if v1=="child2"
replace sor=16 if v1=="LEM"
replace sor=17 if v1=="other"

sort sor

mkmat beta se , mat(A0)


global label coeflabels( ///
r1="Gender wage gap" ///
r2="Total endowments" ///
r3="Work experience" ///
r4="Occupation" ///
r5="STEM degree" ///
r6="Having at least 2 children" ///
r7="Private sector" ///
r8="Underconfidence"  ///
r9="Objective cognitive skills" ///
r10="Education" ///
r11="Having partner" ///
r12="Background" ///
r13="Elite university" ///
r14="Overconfident"  ///
r15="Having one child" ///
r16="LEM degree" ///
r17="Other degree" ///
)


coefplot (matrix(A0[,1]), se(A0[,2])), ///
 xline(0) $label /*title("The contribution of endowments to the gender wage gap")*/ ///
legend(off) graphregion(color(white))

graph save "figures\Figure3_oaxaca_by_gender.gph", replace 
graph export "figures\Figure3_oaxaca_by_gender.png", replace as(png)

cap log close