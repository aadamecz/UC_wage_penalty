*This file specifies how to replicate the results of `Adolescent Underconfidence and the Gender Wage Gap` (Previous title: `The underconfidence wage penalty`) by Anna Adamecz and Nikki Shure, version Nov 2025

*******************
*Data 
*******************
*All data are available from the UK Data Service after registration, creating and account, and asking for permission at wwww.ukdataservice.ac.uk
*After permission is given, download the following datasets of the 1970 British Cohort Study: 

*Age 0: SN 2666 
*Age 5: SN 2699 
*Age 10: SN 3723
*Age 16: SN 3535
*Age 16, math tests: SN 6095
*Age 16, reading tests: SN 8288
*Age 26: SN 3833
*Age 42: SN 7473
*Employment history: SN 6943

*You have to download all datasets manually, one by one. First, go to the data catalogue at
*https://beta.ukdataservice.ac.uk/datacatalogue/studies/#!?Search=&Rows=10&Sort=0&DateFrom=440&DateTo=2023&Page=1
*and enter the identification number of the dataset into the search bar, for example "SN 2666"
*There should be one result with the name of the dataset, please click on that
*Then click on the "Access data" button
*Then add to your account
*Once all datasets are added to your account, go to your account, select all datasets and add them to your project
*Then, you can download the datasets from your project (after reading and signing the user agreements)

********************************************************
*Please copy the following data files into the rawdata folder
********************************************************
*Age 0: bcs1derived.dta; bcs7072a.dta
*Age 5: bcs2derived.dta; f699b.dta; f699c.dta
*Age 10: bcs3derived.dta; sn3723.dta;
*Age 16: bcs4derived.dta; bcs7016x.dta
*Age 16, math tests: bcs70_16-year_arithmetic_data.dta
*Age 16, reading tests: bcs1986_reading_matrices.dta
*Age 26: bcs96x.dt
*Age 42: bcs70_2012_derived.dta; bcs70_2012_flatfile.dta
*Employment history: bcs70_activity_histories_eul.dta

********************
*Software
********************
*We used Stata 17.0 for the analysis

set scheme cleanplots, perm

********************
*To run
********************
clear
clear matrix
clear mata
set maxvar 10000
set seed 123456

*2. Please enter the path to the downloaded replication folder instead of TBA

global folder "TBA\replication package - to Github"
global data "$folder\data"
global rawdata "$folder\rawdata"


cd "$folder"

********************
*Database
********************
do "do\2_OAR_wage_paper_database_to_merge.do"
do "do\3_OAR_wage_paper_outcomes_age42.do"
do "do\4_OAR_wage_paper_database.do"

********************
*Analysis
********************
do "do\5_OAR_wage_paper_descriptives.do"
do "do\6_OAR_wage_paper_models.do"
do "do\7_OAR_wage_paper_Figure2.do"
do "do\8_OAR_wage_paper_oaxaca.do"
do "do\9_OAR_wage_paper_oaxaca_byUC.do"
do "do\10_OAR_wage_paper_robustness.do"