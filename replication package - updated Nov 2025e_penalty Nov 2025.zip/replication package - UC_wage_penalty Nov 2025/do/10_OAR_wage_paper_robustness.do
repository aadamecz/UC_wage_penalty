cap log close
log using "logs\10_OAR_wage_paper_robustness.smcl", replace

use "$data\background.dta", replace /*created by 4_OAR_wage_paper_database.do, line 222*/

*********************************
*Merging main analytical sample
*********************************
merge 1:1 bcsid using "$data\OAR_wage_paper_database_FTemployed.dta"

tab main_sample, m
replace main_sample=0 if main_sample==.
drop _merge

tab female female_0, m
tab female female_5, m
tab female_0 female_5, m

replace female=female_0 if female==.
replace female=female_5 if female==.
tab female, m

*****************************
***Sample selection models***
*****************************
tab mage_education, m

replace mage_education=99 if (mage_education==97 | mage_education==.)
replace mage_education=13 if mage_education<13
replace mage_education=20 if mage_education>20 & mage_education!=99 

cap drop ethnicity
gen ethnicity=0
replace ethnicity=1 if e245==1
lab var ethnicity "British"

global controls i.region i.social_class ethnicity low_bw myob myob_imp i.first_born i.mage_education mother_employed_age0 mother_married_age0 premarital_conception i.only_child_inHH_age5 

xi: sum $controls female if main_sample==0
xi: sum $controls female if main_sample==1


gen mainsample=main_sample

*weights from a probit model
set trace off
xi: probit mainsample $controls if female==0
predict inv1_f0 if female==0, pr
roctab mainsample inv1_f0 if female==0
gen probitweight_f0=1/inv1_f0 if female==0

xi: probit mainsample $controls if female==1
predict inv1_f1 if female==1, pr
roctab mainsample inv1_f1 if female==1
gen probitweight_f1=1/inv1_f1 if female==1

gen probitweight=probitweight_f0 if female==0
replace probitweight=probitweight_f1 if female==1


*weights for a random forest model
xi: rforest mainsample $controls if female==0, type(class)
predict t0 rf_f0 if female==0, pr
roctab mainsample rf_f0 if female==0
gen rfweight_f0=1/rf_f0 if female==0

xi: rforest mainsample $controls if female==1, type(class)
predict t1 rf_female if female==1, pr
roctab mainsample rf_female if female==1
gen rfweight_f1=1/rf_female if female==1

gen rfweight=rfweight_f1 if female==1
replace rfweight=rfweight_f0 if female==0


*Entropy balancing
gen inv_mainsample=abs(mainsample-1)
xi: ebalance inv_mainsample $controls if female==0, gen(eweight_f0) keep(results\OCebalance_0) replace
lab var eweight_f0 "Estimated entropy weights, men"

xi: ebalance inv_mainsample $controls if female==1, gen(eweight_f1) keep(results\OCebalance_1) replace
lab var eweight_f1 "Estimated entropy weights, women"

gen eweight=eweight_f1 if female==1
replace eweight=eweight_f0 if female==0

sum probitweight rfweight  eweight 
corr probitweight rfweight  eweight 

****************************
*Tables OA10-OA12: The gender wage gap, weighted estimates
****************************
global controls0 i.region SES m_quali i.ethnicity 

global outreg  dec(3) noomitted label noni  ///
drop(1.region 2.region 3.region 4.region 5.region 6.region 7.region 8.region 9.region 10.region 11.region 99.region ///
1.ethnicity 2.ethnicity 3.ethnicity 4.ethnicity 5.ethnicity 6.ethnicity 7.ethnicity 8.ethnicity 99.ethnicity ///
SES m_quali 1.private_grammar 2.private_grammar 99.private_grammar  ///
1.math_O_CSE 2.math_O_CSE 3.math_O_CSE 4.math_O_CSE 5.math_O_CSE 6.math_O_CSE 7.math_O_CSE 99.math_O_CSE ///
A_level) nonotes word excel  alpha(0.001, 0.01, 0.05)

global sort  female overconfidence_score cognitive_cfa
global outcome log_hourlypay_42

local list probitweight rfweight  eweight 
foreach item in `list' {
global model `item'	
	
reg  $outcome female [aw=`item'], vce(robust) 

outreg2 using "results\\${model}.doc" ,  replace ctitle(Model 1) $outreg sortvar($sort )

reg $outcome female overconfidence_score [aw=`item'],  vce(robust) 

outreg2 using "results\\${model}.doc",  ctitle(Model 2)  $outreg 

reg $outcome female  overconfidence_score cognitive_cfa [aw=`item'],  vce(robust) 
outreg2 using "results\\${model}.doc" ,  ctitle(Model 3)  $outreg  

reg $outcome female overconfidence_score cognitive_cfa $controls0 [aw=`item'],  vce(robust) 
outreg2 using "results\\${model}.doc", ctitle(Model 4A)  $outreg addtext("Social background, Yes") 

global sort   female overconfidence_score cognitive_cfa conf_irt underconfident overconfident 

reg $outcome female conf_irt cognitive_cfa $controls0 [aw=`item'],  vce(robust) 
outreg2 using "results\\${model}.doc", ctitle(Model 4B )  $outreg addtext("Social background, Yes") 

reg $outcome female underconfident overconfident  cognitive_cfa $controls0 [aw=`item'],  vce(robust) 
outreg2 using "results\\${model}.doc", ctitle(Model 4C)  $outreg addtext("Social background, Yes") 

}

cap log close
