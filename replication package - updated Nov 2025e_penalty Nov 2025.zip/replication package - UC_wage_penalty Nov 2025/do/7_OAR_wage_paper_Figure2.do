
***********************
*Channels
***********************

cap log close 
log using "logs\7_OAR_wage_paper_Figure2", replace
**************
*Main table OC
**************
global outcome log_hourlypay_42
global model tableA6

use "$data\OAR_wage_paper_database_FTemployed.dta", clear

global controls0 i.region SES m_quali i.ethnicity 
global channels1 $controls0 i.private_grammar i.math_O_CSE i.A_level
global channels2 $channels1 STEM LEM other elite_uni 
global channels3 $channels2 i.SOC2000_2digit i.private_sector emp_42
global channels4 $channels3 partner_age42  child2 child3

global outreg dec(3) tex(fragment) noomitted label noni  ///
nonotes word alpha(0.001, 0.01, 0.05)


*Model 1
reg  $outcome female , vce(robust) 
mat A1=(1,_b[female],_se[female],.,.,.,.)

outreg2 using "results\\${model}.doc" , replace  ctitle(Model 1)  $outreg 

*Model 2
reg  $outcome female overconfident underconfident, vce(robust) 
mat A2=(2,_b[female],_se[female],_b[underconfident],_se[underconfident],_b[overconfident],_se[overconfident])

outreg2 using "results\\${model}.doc" ,  ctitle(Model 2)  $outreg 


*Model 3
reg $outcome female overconfident underconfident cognitive_cfa ,  vce(robust) 
mat A3=(3,_b[female],_se[female],_b[underconfident],_se[underconfident],_b[overconfident],_se[overconfident])

outreg2 using "results\\${model}.doc" ,  ctitle(Model 3)  $outreg 

*Model 4
reg $outcome female overconfident underconfident cognitive_cfa $controls0 ,  vce(robust) 
mat A4=(4,_b[female],_se[female],_b[underconfident],_se[underconfident],_b[overconfident],_se[overconfident])

outreg2 using "results\\${model}.doc" ,  ctitle(Model 4)  $outreg ///
addtext(Background, Yes) 

*Model 5
reg $outcome female overconfident underconfident cognitive_cfa $channels1 ,  vce(robust) 
mat A5=(5,_b[female],_se[female],_b[underconfident],_se[underconfident],_b[overconfident],_se[overconfident])

outreg2 using "results\\${model}.doc" , ctitle(Model 5)  $outreg ///
addtext(Background, Yes,Pre-uni education, Yes) 

*Model 6
reg $outcome female overconfident underconfident cognitive_cfa $channels2 ,  vce(robust) 
mat A6=(6,_b[female],_se[female],_b[underconfident],_se[underconfident],_b[overconfident],_se[overconfident])

outreg2 using "results\\${model}.doc" , ctitle(Model 6)  $outreg ///
addtext(Background, Yes,Pre-uni education, Yes,Graduation, Yes) 

*Model 7
reg $outcome female overconfident underconfident cognitive_cfa $channels3 ,  vce(robust) 
mat A7=(7,_b[female],_se[female],_b[underconfident],_se[underconfident],_b[overconfident],_se[overconfident])

outreg2 using "results\\${model}.doc" , ctitle(Model 7)  $outreg ///
addtext(Background, Yes,Pre-uni education, Yes,Graduation, Yes,Occupation codes, Yes ) 


*Model 8
reg $outcome female overconfident underconfident cognitive_cfa $channels4 ,  vce(robust) 
mat A8=(8,_b[female],_se[female],_b[underconfident],_se[underconfident],_b[overconfident],_se[overconfident])

outreg2 using "results\\${model}.doc" , ctitle(Model 8)  $outreg ///
addtext(Background, Yes , Pre-uni education, Yes,Graduation, Yes,Occupation codes, Yes,Partner and children, Yes ) 

*****************
*Coeffplot - Figure 2
***********************
mat A=A1\A2\A3\A4\A5\A6\A7\A8
mat colnames A=model female_beta female_se under_beta under_se over_beta over_se
mat list A
preserve
clear
svmat A, names(col)
local list2 female under over
global order 
foreach item2 in `list2' {
gen low_`item2'=`item2'_beta - 1.96 * `item2'_se
gen high_`item2'=`item2'_beta + 1.96 * `item2'_se
global order $order `item2'_beta low_`item2' high_`item2'
}

save "results\Figure2_data.dta", replace

***************
*Figure
***************
use "results\Figure2_data.dta", clear

global order female_beta low_female high_female under_beta low_under high_under over_beta low_over high_over model  
gsort  +model
order $order

mkmat $order , mat(C1)

global label r1="Model 1: female only" r2="Model 2: + OC/UC " r3="Model 3: + objective skills" r4="Model 4: + background" r5="Model 5: + education" r6="Model 6: + graduation" r7="Model 7: + employment" r8="Model 8: + family" 

coefplot (matrix(C1[,1]), ci((C1[,2] C1[,3])) msymbol(circle) mcolor(gs5) ciopts(color(gs5))) ///
(matrix(C1[,4]), ci((C1[,5] C1[,6])) msymbol(square) mcolor(red) ciopts(color(red)))  ///
(matrix(C1[,7]), ci((C1[,8] C1[,9])) msymbol(triangle) mcolor(gs10) ciopts(color(gs10))), ///
coeflabels($label , labsize(small) )  graphregion(color(white))  ///
legend(label(2 "Coefficients on female") label(4 "Coefficients on underconfident") label(6 "Coefficients on overconfident") col(1) size(small)) ///
xline(0) 

graph export "figures\Figure2_coeffplot.png", replace as(png)

cap log close


