cap log close
log using "logs\3_OAR_wage_paper_outcomes_age42.smcl", replace

*************************************
*Age 42: labour market outcomes and detailed info on higher education
*************************************
use "$rawdata\bcs70_2012_derived.dta" , clear

*academic qualification
egen highest_qual_age42=rowmax(BD9ACHQ1 BD9HACHQ)

/*label list BD9ACHQ1 - same label for both BD9ACHQ1 and BD9HACHQ
BD9ACHQ1:
          -8 not enough information
          -1 not applicable
           0 no academic qualification
           1 gcse d-e
           2 cses2-5, other scottish quals
           3 gcse a-c, good o levels scot standards
           4 as levels or 1 a level
           5 2+ a levels, scot higher/6th
           6 diploma
           7 degree level
           8 higher degree
*/

tab highest_qual_age42, m

/*highest_qua |
    l_age42 |      Freq.     Percent        Cum.
------------+-----------------------------------
          0 |      2,895       29.42       29.42
          1 |         45        0.46       29.88
          2 |        606        6.16       36.03
          3 |      2,433       24.72       60.76
          4 |        184        1.87       62.63
          5 |        356        3.62       66.24
          6 |        825        8.38       74.63
          7 |      2,018       20.51       95.13
          8 |        479        4.87      100.00
------------+-----------------------------------
      Total |      9,841      100.00
*/

lab var highest_qual_age42 "Highest qualification at age 42"
lab val highest_qual_age42 BD9ACHQ1

****Labels**********
tab highest_qual_age42, gen(qualification42)
levelsof highest_qual_age42
local i=1
local lab: value label highest_qual_age42
foreach value in `r(levels)' {
	local label: label `lab' `value'
	lab var qualification42`i' "`label'"
	local i=`i'+1
	}
	
gen graduate_age42=0
replace graduate_age42=1 if highest_qual_age42==7 | highest_qual_age42==8

*economic activity
rename BD9ECACT activity_age42
/* label list BD9ECACT
BD9ECACT:
          -9 Refused
          -8 Not enough information
          -1 Not applicable
           1 Full-time employment
           2 Part-time employment
           3 Full-time self-employment
           4 Part-time self-employment
           5 Unemployment
           6 Full-time education
           7 Govt scheme for employment training
           8 Temporary sickness/disablity
           9 Permanent sickness/disablity
          10 Looking after the home/family
          11 Retirement
          12 Other
*/

gen employed_age42=0 if activity_age42>0
replace employed_age42=1 if activity_age42>=1 & activity_age42<=4
lab var employed_age42 "Employed, age 42"

*type of employment
gen emp_type_age42=99 
replace emp_type_age42=1 if activity_age42==1 /*full-time*/
replace emp_type_age42=2 if activity_age42==2 /*part-time*/
replace emp_type_age42=3 if activity_age42==3 | activity_age42==4 /*self-employed*/

lab def lemp_type ///
1 "Employed full-time" ///
2 "Employed part-time" ///
3 "Self-employed" ///
99 "Employment type missing"

lab val emp_type_age42 lemp_type
tab emp_type_age42


tab emp_type_age42, gen(emptype42)
levelsof emp_type_age42
local i=1
local lab: value label emp_type_age42
foreach value in `r(levels)' {
	local label: label `lab' `value'
	lab var emptype42`i' "`label'"
	local i=`i'+1
	}


	
rename BD9GOR region_age42
lab var region_age42 "Region, age 42"

/*label list BD9GOR
BD9GOR:
          -1 Not applicable (not resident in UK)
           1 North East
           2 North West
           3 Yorkshire and Humberberside
           4 East Midlands
           5 West Midlands
           6 East of England
           7 London
           8 South East
           9 South West
          10 Wales
          11 Scotland
          12 Northern Ireland
*/

rename BD9COHAB partner_age42
replace partner_age42=0 if partner_age42<0
lab var partner_age42 "Has cohabiting partner, age 42"

rename BD9NUMCH children_age42
replace children_age42=2 if children_age42>=2 & children_age42!=.
lab var children_age42 "No. of children in HH, age 42"
tab children_age42, m


global keep1 region_age42 partner_age42 children_age42 activity_age42 highest_qual_age42 qualification42* graduate_age42 employed_age42 emptype42* emp_type_age42 BD9MAL BD9MALG 
keep BCSID $keep1

merge 1:1 BCSID using "$rawdata\bcs70_2012_flatfile.dta"
drop _merge


*************************
*If last pay is usual pay
**************************

label list B9NETP
/*B9NETP:
          -9 Refused
          -8 Don't know
          -1 Not applicable
           1 One week
           2 Two weeks
           3 Three weeks
           4 Four weeks
           5 Calendar month
           7 Two calendar months
           8 Eight times a year
           9 Nine times a year
          10 Ten times a year
          13 Three months/13 weeks
          26 Six months/26 weeks
          52 One year/12 months/52 weeks
          90 Less than one week
          95 Lump sum/one off
          96 None of these
          99 na
*/
gen weekly_pay_42=B9NETA if B9NETP==1 & B9PUSL==1
replace weekly_pay_42=B9NETA/2 if B9NETP==2 & B9PUSL==1
replace weekly_pay_42=B9NETA/3 if B9NETP==3 & B9PUSL==1
replace weekly_pay_42=B9NETA/4 if B9NETP==4 & B9PUSL==1
replace weekly_pay_42=B9NETA/(52/12) if B9NETP==5 & B9PUSL==1
replace weekly_pay_42=B9NETA/(2*52/12) if B9NETP==7 & B9PUSL==1
replace weekly_pay_42=B9NETA/( 365/8/7) if B9NETP==8 & B9PUSL==1
replace weekly_pay_42=B9NETA/( 365/9/7) if B9NETP==9 & B9PUSL==1
replace weekly_pay_42=B9NETA/( 365/10/7) if B9NETP==10 & B9PUSL==1
replace weekly_pay_42=B9NETA/13 if B9NETP==13 & B9PUSL==1
replace weekly_pay_42=B9NETA/26 if B9NETP==26 & B9PUSL==1
replace weekly_pay_42=B9NETA/52 if B9NETP==52 & B9PUSL==1
replace weekly_pay_42=B9NETA/5 if B9NETP==90 & B9PUSL==1


*************************
*If last pay is not usual pay
*************************
label list B9USLP
tab B9USLP
/*B9USLP:
          -9 Refused
          -8 Don't know
          -1 Not applicable
           1 One week
           2 Two weeks
           3 Three weeks
           4 Four weeks
           5 Calendar month
           7 Two calendar months
		   
           /*8 Eight times a year
           9 Nine times a year
          10 Ten times a year
          13 Three months/13 weeks
          26 Six months/26 weeks*/
		  
          52 One year/12 months/52 weeks
          90 Less than one week
          95 Lump sum/one off
          96 None of these
          99 na
*/

replace weekly_pay_42=B9USLA if weekly_pay_42==. & B9PUSL==2 & B9USLP==1
replace weekly_pay_42=B9USLA/2 if weekly_pay_42==. & B9PUSL==2 & B9USLP==2
replace weekly_pay_42=B9USLA/3 if weekly_pay_42==. & B9PUSL==2 & B9USLP==3
replace weekly_pay_42=B9USLA/4 if weekly_pay_42==. & B9PUSL==2 & B9USLP==4
replace weekly_pay_42=B9USLA/(52/12) if weekly_pay_42==. & B9PUSL==2 & B9USLP==5
replace weekly_pay_42=B9USLA/(2*52/12) if weekly_pay_42==. & B9PUSL==2 & B9USLP==7
replace weekly_pay_42=B9USLA/52 if weekly_pay_42==. & B9PUSL==2 & B9USLP==12
replace weekly_pay_42=B9USLA/5 if weekly_pay_42==. & B9PUSL==2 & B9USLP==90
replace weekly_pay_42=. if weekly_pay_42<=0

gen weekly_hours_42=B9CHOUR1 if B9CHOUR1>0 & B9CHOUR1!=.
replace weekly_hours_42=B9CHOUR if weekly_hours_42==. & B9CHOUR1<0 & B9CHOUR>0 & B9CHOUR!=.

gen hourlypay_42=weekly_pay_42/weekly_hours_42
hist hourlypay_42
replace hourlypay_42=. if hourlypay_42==0 | hourlypay_42<0

hist hourlypay_42
tab  hourlypay_42, m
gen log_hourlypay_42=log(hourlypay_42)

hist log_hourlypay_42
replace log_hourlypay_42=. if log_hourlypay_42<=0
sum log_hourlypay_42

*Occupation
rename  B9CS2000 SOC2000

tab SOC2000
replace SOC2000=. if SOC2000<0

gen SOC2000_2digit=int(SOC2000/100)
replace SOC2000_2digit=99 if SOC2000_2digit==. & log_hourlypay_42!=.
tab SOC2000_2digit

*Private sector employment
gen private_sector=0
replace  private_sector=1 if  B9CJORG==1
lab var private_sector "Works in the private sector"


*Subject of degree
describe B9SBDG*

/*
variable name   type    format     label      variable label
----------------------------------------------------------------------------------------------------
B9SBDG01        byte    %8.0g      B9SBDG01   Subject of degree: Agriculture and forestry
B9SBDG02        byte    %8.0g      B9SBDG02   Subject of degree: American studies
B9SBDG03        byte    %8.0g      B9SBDG03   Subject of degree: Anatomy and physiology
B9SBDG04        byte    %8.0g      B9SBDG04   Subject of degree: Anthropology
B9SBDG05        byte    %8.0g      B9SBDG05   Subject of degree: Archaeology
B9SBDG06        byte    %8.0g      B9SBDG06   Subject of degree: Architecture
B9SBDG07        byte    %8.0g      B9SBDG07   Subject of degree: Art and design
B9SBDG08        byte    %8.0g      B9SBDG08   Subject of degree: Biosciences
B9SBDG09        byte    %8.0g      B9SBDG09   Subject of degree: Building and town and country
                                                planning
B9SBDG10        byte    %8.0g      B9SBDG10   Subject of degree: Business and management studies
B9SBDG11        byte    %8.0g      B9SBDG11   Subject of degree: Chemical engineering
B9SBDG12        byte    %8.0g      B9SBDG12   Subject of degree: Chemistry
B9SBDG13        byte    %8.0g      B9SBDG13   Subject of degree: Civil engineering
B9SBDG14        byte    %8.0g      B9SBDG14   Subject of degree: Classics
B9SBDG15        byte    %8.0g      B9SBDG15   Subject of degree: Computer science and IT
B9SBDG16        byte    %8.0g      B9SBDG16   Subject of degree: Dentistry
B9SBDG17        byte    %8.0g      B9SBDG17   Subject of degree: Drama and dance
B9SBDG18        byte    %8.0g      B9SBDG18   Subject of degree: Earth and marine sciences
B9SBDG19        byte    %8.0g      B9SBDG19   Subject of degree: Economics
B9SBDG20        byte    %8.0g      B9SBDG20   Subject of degree: Education degree courses
B9SBDG21        byte    %8.0g      B9SBDG21   Subject of degree: Electronics and electrical
                                                engineering
B9SBDG22        byte    %8.0g      B9SBDG22   Subject of degree: Engineering general
B9SBDG23        byte    %8.0g      B9SBDG23   Subject of degree: English
B9SBDG24        byte    %8.0g      B9SBDG24   Subject of degree: Geography and environment studies
B9SBDG25        byte    %8.0g      B9SBDG25   Subject of degree: History and history of art
B9SBDG26        byte    %8.0g      B9SBDG26   Subject of degree: Law
B9SBDG27        byte    %8.0g      B9SBDG27   Subject of degree: Materials and mineral engineering
B9SBDG28        byte    %8.0g      B9SBDG28   Subject of degree: Mathematics
B9SBDG29        byte    %8.0g      B9SBDG29   Subject of degree: Mechanical engineering
B9SBDG30        byte    %8.0g      B9SBDG30   Subject of degree: Media studies, communications and
                                                librarianship
B9SBDG31        byte    %8.0g      B9SBDG31   Subject of degree: Medicine
B9SBDG32        byte    %8.0g      B9SBDG32   Subject of degree: Modern languages
B9SBDG33        byte    %8.0g      B9SBDG33   Subject of degree: Music
B9SBDG34        byte    %8.0g      B9SBDG34   Subject of degree: Nursing
B9SBDG35        byte    %8.0g      B9SBDG35   Subject of degree: Pharmacy and pharmacology
B9SBDG36        byte    %8.0g      B9SBDG36   Subject of degree: Philosophy
B9SBDG37        byte    %8.0g      B9SBDG37   Subject of degree: Physics
B9SBDG38        byte    %8.0g      B9SBDG38   Subject of degree: Politics
B9SBDG39        byte    %8.0g      B9SBDG39   Subject of degree: Psychology
B9SBDG40        byte    %8.0g      B9SBDG40   Subject of degree: Religious studies and theology
B9SBDG41        byte    %8.0g      B9SBDG41   Subject of degree: Social policy and administration
B9SBDG42        byte    %8.0g      B9SBDG42   Subject of degree: Social work
B9SBDG43        byte    %8.0g      B9SBDG43   Subject of degree: Sociology
B9SBDG44        byte    %8.0g      B9SBDG44   Subject of degree: Sports science
B9SBDG45        byte    %8.0g      B9SBDG45   Subject of degree: Tourism, transport and travel
B9SBDG46        byte    %8.0g      B9SBDG46   Subject of degree: Veterinary science
B9SBDG47        byte    %8.0g      B9SBDG47   Subject of degree: Estate management
B9SBDG48        byte    %8.0g      B9SBDG48   Subject of degree: Accountancy
B9SBDG49        byte    %8.0g      B9SBDG49   Subject of degree: Marketing
B9SBDG50        byte    %8.0g      B9SBDG50   Subject of degree: Other
B9SBDG51        byte    %8.0g      B9SBDG51   Subject of degree: Don't know
B9SBDG52        byte    %8.0g      B9SBDG52   Subject of degree: Refused
*/

*STEM
gen course=.
local list B9SBDG01 B9SBDG03 B9SBDG06 B9SBDG08 B9SBDG09 B9SBDG11 B9SBDG12 B9SBDG13 ///
B9SBDG15 B9SBDG16 B9SBDG18 B9SBDG21 B9SBDG22 B9SBDG24 B9SBDG27 B9SBDG28 B9SBDG29 B9SBDG31 B9SBDG34 B9SBDG35 B9SBDG37 ///
B9SBDG44 B9SBDG46
foreach item in `list' {
replace course=1 if `item'==1
}

*LEM
local list B9SBDG10 B9SBDG19 B9SBDG26 B9SBDG41 B9SBDG45 B9SBDG47 ///
B9SBDG48 B9SBDG49

foreach item in `list' {
replace course=2 if `item'==1 & course==.
}

*OSSAH
local list B9SBDG02 B9SBDG04 B9SBDG05 B9SBDG07 B9SBDG14 B9SBDG17 B9SBDG20 B9SBDG23 B9SBDG25 B9SBDG30 ///
B9SBDG32 B9SBDG33 B9SBDG36 B9SBDG38 B9SBDG39 B9SBDG40 B9SBDG42 B9SBDG43
foreach item in `list' {
replace course=3 if `item'==1 & course==.
}

*Other/unknown
local list B9SBDG50 B9SBDG51 B9SBDG52
foreach item in `list' {
replace course=4 if `item'==1 & course==.
}


local list B9SBDG01 B9SBDG02 B9SBDG03 B9SBDG04 B9SBDG05 B9SBDG06 B9SBDG07 B9SBDG08 B9SBDG09 B9SBDG10 B9SBDG11 B9SBDG12 B9SBDG13 B9SBDG14 B9SBDG15 B9SBDG16 B9SBDG17 B9SBDG18 B9SBDG19 B9SBDG20 B9SBDG21 B9SBDG22 B9SBDG23 B9SBDG24 B9SBDG25 B9SBDG26 B9SBDG27 B9SBDG28 B9SBDG29 B9SBDG30 B9SBDG31 B9SBDG32 B9SBDG33 B9SBDG34 B9SBDG35 B9SBDG36 B9SBDG37 B9SBDG38 B9SBDG39 B9SBDG40 B9SBDG41 B9SBDG42 B9SBDG43 B9SBDG44 B9SBDG45 B9SBDG46 B9SBDG47 B9SBDG48 B9SBDG49 B9SBDG50 B9SBDG51 B9SBDG52
foreach item in `list' {
replace `item'=0 if `item'!=1
}

egen no_of_subjects=rowtotal(`list')
tab no_of_subjects

replace course=5 if (no_of_subjects>1 & no_of_subjects!=. & course!=1 & course!=2)
label def course ///
1 "STEM" 2 "LEM" 3 "OSSAH" 4 "Other" 5 "COMB"
lab val course course

tab course graduate_age42, m
replace graduate_age42=1 if course>=1 & course<=5
tab course graduate_age42, m

*tab B9UNIDGN
/*RUSSELL GROUP UNIVERSITIES
 label list B9UNIDGN
12 The University of Birmingham
21 The University of Bristol
25 The University of Cambridge
29 Cardiff University
43 University of Durham
47 Uni of Edinburgh/Edinburgh College Art
51 The University of Exeter
54 The University of Glasgow
69 Imperial College of Science etc
72 King's College London
 75 The University of Leeds
 81 The University of Liverpool
       90 London School of Economics Pol Sci
          94 Uni of Manchester/Victoria/UMIST
          97 The University of Newcastle-upon-Tyne
102 The University of Nottingham
105 The University of Oxford
         111 Queen Mary and Westfield College
         112 The Queen's University of Belfast
		 130 The University of Sheffield
         132 The University of Southampton
85 University College London 
155 The University of Warwick
164 The University of York
*/

gen RG=0
local list 12 21 25 29 43 47 51 54 69 72 75 81 90 94 97 102 105 111 112 130 132 85 155 164
foreach item in `list' {
replace RG=1 if B9UNIDGN==`item'
}

tab RG graduate_age42, m
tab course graduate_age42, m

replace course=0 if course==.
tab course RG, m

gen RG_subject=course if RG==0
replace RG_subject=course+5 if RG==1
tab RG_subject graduate_age42, m
tab RG_subject RG, m
tab RG_subject course, m

label def RG_subject ///
0 "No degree" 1 "STEM" 2 "LEM" 3 "OSSAH" 4 "Other" 5 "Combined" 6 "Elite STEM" 7 "Elite LEM" 8 "Elite OSSAH" 9 "Elite other" 10 "Elite combined" 
lab val RG_subject RG_subject


save "$data\outcomes42.dta", replace



