***************************-
*OAXACA
**************************
cap log close 
log using "logs\9_OAR_wage_paper_oaxaca_byUC", replace


use "$data\OAR_wage_paper_database_FTemployed.dta", clear


global outcome log_hourlypay_42

global controls0 i.region SES m_quali i.ethnicity 
global channels1 $controls0 i.private_grammar i.math_O_CSE i.A_level
global channels2 $channels1 STEM LEM other elite_uni 
global channels3 $channels2 i.SOC2000_2digit i.private_sector emp_42
global channels4 $channels3 partner_age42  child2 child3



*aggregates
global back _Iregion_2 _Iregion_3 _Iregion_4 _Iregion_5 _Iregion_6 _Iregion_7 _Iregion_8 _Iregion_9 _Iregion_10 _Iregion_11 _Iregion_99 _Iethnicity_2 _Iethnicity_3 _Iethnicity_4 _Iethnicity_5 _Iethnicity_6 _Iethnicity_7 _Iethnicity_8 _Iethnicity_99 SES m_quali

global educ _Iprivate_g_1 _Iprivate_g_99 _Imath_O_CS_1 _Imath_O_CS_2 _Imath_O_CS_3 _Imath_O_CS_4 _Imath_O_CS_5 _Imath_O_CS_6 _Imath_O_CS_99 _IA_level_1

global soc  _ISOC2000_2_12 _ISOC2000_2_21 _ISOC2000_2_22 _ISOC2000_2_23 _ISOC2000_2_24 _ISOC2000_2_31 _ISOC2000_2_32 _ISOC2000_2_33 _ISOC2000_2_34 _ISOC2000_2_35 _ISOC2000_2_41 _ISOC2000_2_42 _ISOC2000_2_51 _ISOC2000_2_52 _ISOC2000_2_53 _ISOC2000_2_54 _ISOC2000_2_61 _ISOC2000_2_62 _ISOC2000_2_71 _ISOC2000_2_72 _ISOC2000_2_81 _ISOC2000_2_82 _ISOC2000_2_91 _ISOC2000_2_92 _ISOC2000_2_99


global detail "Background: $back , Education: $educ, Occupation: $soc"

*Compared to the rest 2/3-s of the distribution
xi: oaxaca $outcome cognitive_cfa $channels4 if female==0  , by(underconfident) pool detail detail($detail ) relax
outreg2 using "results\oaxaca_detailed_42_UC.xls", replace bdec(3) sdec(3) noparen  sideway stats(coef se) noaster 

xi: oaxaca $outcome cognitive_cfa $channels4 if female==1  , by(underconfident) pool detail detail($detail ) relax
outreg2 using "results\oaxaca_detailed_42_UC.xls", append bdec(3) sdec(3) noparen  sideway stats(coef se) noaster 


************************************************
*Underconfident compared to the middle tertile
*************************************************
drop if overconfident==1

xi: oaxaca $outcome cognitive_cfa $channels4 if female==0  , by(underconfident) pool detail detail($detail ) relax
outreg2 using "results\oaxaca_detailed_42_UC_M.xls", replace bdec(3) sdec(3) noparen  sideway stats(coef se) noaster 

xi: oaxaca $outcome cognitive_cfa $channels4 if female==1  , by(underconfident) pool detail detail($detail ) relax
outreg2 using "results\oaxaca_detailed_42_UC_M.xls", append bdec(3) sdec(3) noparen  sideway stats(coef se) noaster 


*************************************************************
*Figure 4: The decomposition of the Underconfidence wage gap - endowments, lowest tertile compared to the rest two-thirds of the sample
*************************************************************
import delimited  "results\oaxaca_detailed_42_UC.txt",  rowrange(4:22) clear

replace v4=v2 if v4=="" | v4=="."
replace v5=v3 if v5=="" | v5=="."
replace v10=v8 if v10=="" | v10=="."
replace v11=v9 if v11=="" | v11=="."

drop v2 v3 v8 v9 v6 v12
drop if v1=="overall" | v1=="group_1" | v1=="group_2" | v1=="unexplained" 

rename v4 beta_men
rename v5 se_men
rename v10 beta_women
rename v11 se_women

destring beta_men , replace
destring se_men , replace
destring beta_women , replace
destring se_women, replace

gsort -beta_men

/*
v1
difference
explained
Occupation
Education
STEM
LEM
cognitive_cfa
elite_uni
Background
partner_age42
other
child3
child2
emp_42
_Iprivate_s_1
*/


gen sor=1 if v1=="difference"
replace sor=2 if v1=="explained"
replace sor=3 if v1=="Occupation"
replace sor=4 if v1=="Education"
replace sor=5 if v1=="STEM"
replace sor=6 if v1=="LEM"
replace sor=7 if v1=="cognitive_cfa"
replace sor=8 if v1=="elite_uni"
replace sor=9 if v1=="Background"
replace sor=10 if v1=="partner_age42"
replace sor=11 if v1=="other"
replace sor=12 if v1=="child3"
replace sor=13 if v1=="child2"
replace sor=14 if v1=="emp_42"
replace sor=15 if v1=="_Iprivate_s_1"

sort sor

mkmat beta_men se_men , mat(A0)
mkmat beta_women se_women , mat(A1)


global label coeflabels( ///
r1="Underconfident wage penalty" ///
r2="Total endowments" ///
r3="Occupation" ///
r4="Education" ///
r5="STEM degree" ///
r6="LEM degree" ///
r7="Objective cognitive skills" ///
r8="Elite university" ///
r9="Background" ///
r10="Having partner" ///
r11="Other degree" ///
r12="Having at least 2 children" ///
r13="Having one child" ///
r14="Work experience" ///
r15="Private sector")


coefplot (matrix(A0[,1]), se(A0[,2])) ///
(matrix(A1[,1]), se(A1[,2])) ///
,  xline(0) $label /*title("The contribution of endowments to the gender wage gap")*/ ///
legend(label(2 "Men") label(4 "Women")) graphregion(color(white))

graph save "figures\Figure4_oaxaca_by_underconfident.gph", replace 
graph export "figures\Figure4_oaxaca_by_underconfident.png", replace as(png)



*************************************************************
*Figure A4: The decomposition of the Underconfidence wage gap - endowments, lowest tertile compared to the middle tertile
*************************************************************
import delimited  "results\oaxaca_detailed_42_UC_M.txt",  rowrange(4:22) clear

replace v4=v2 if v4=="" | v4=="."
replace v5=v3 if v5=="" | v5=="."
replace v10=v8 if v10=="" | v10=="."
replace v11=v9 if v11=="" | v11=="."

drop v2 v3 v8 v9 v6 v12
drop if v1=="overall" | v1=="group_1" | v1=="group_2" | v1=="unexplained" 

rename v4 beta_men
rename v5 se_men
rename v10 beta_women
rename v11 se_women

destring beta_men , replace
destring se_men , replace
destring beta_women , replace
destring se_women, replace

gsort -beta_men

/*
v1
difference
explained
Occupation
LEM
Education
cognitive_cfa
STEM
child3
partner_age42
other
child2
emp_42
_Iprivate_s_1
elite_uni
Background
*/

gen sor=1 if v1=="difference"
replace sor=2 if v1=="explained"
replace sor=3 if v1=="Occupation"
replace sor=4 if v1=="LEM"
replace sor=5 if v1=="Education"
replace sor=6 if v1=="cognitive_cfa"
replace sor=7 if v1=="STEM"
replace sor=8 if v1=="child3"
replace sor=9 if v1=="partner_age42"
replace sor=10 if v1=="other"
replace sor=11 if v1=="child2"
replace sor=12 if v1=="emp_42"
replace sor=13 if v1=="_Iprivate_s_1"
replace sor=14 if v1=="elite_uni"
replace sor=15 if v1=="Background"

sort sor

mkmat beta_men se_men , mat(A0)
mkmat beta_women se_women , mat(A1)


global label coeflabels( ///
r1="Underconfident wage penalty" ///
r2="Total endowments" ///
r3="Occupation" ///
r5="LEM degree" ///
r4="Education" ///
r6="Objective cognitive skills" ///
r7="STEM degree" ///
r11="Having at least 2 children" ///
r12="Having partner" ///
r10="Other degree" ///
r14="Having one child" ///
r13="Work experience" ///
r15="Private sector" ///
r8="Elite university" ///
r9="Background" ///
)

coefplot (matrix(A0[,1]), se(A0[,2])) ///
(matrix(A1[,1]), se(A1[,2])) ///
,  xline(0) $label /*title("The contribution of endowments to the gender wage gap")*/ ///
legend(label(2 "Men") label(4 "Women")) graphregion(color(white))

graph save "figures\FigureA4_oaxaca_by_underconfident_M.gph", replace 
graph export "figures\FigureA4_oaxaca_by_underconfident_M.png", replace as(png)

cap log close