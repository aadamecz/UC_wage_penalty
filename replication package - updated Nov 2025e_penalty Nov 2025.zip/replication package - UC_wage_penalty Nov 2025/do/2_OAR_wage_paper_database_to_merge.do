
cap log close
log using "logs\2_OAR_wage_paper_database_to_merge.smcl", replace

******************************
*Cognitive measures at age 5
******************************
use "$rawdata\f699c.dta" , clear

*English Picture Vocabulary Test
* https://www.closer.ac.uk/cross-study-data-guides/cognitive-measures-guide/bcs70-cognition/bcs70-age-5-english-picture-vocabulary-test-epvt/

*Copying Designs Test
*https://www.closer.ac.uk/cross-study-data-guides/cognitive-measures-guide/bcs70-cognition/bcs70-age-5-copying-designs-test-cdt/

*Human Figure Drawing
*https://www.closer.ac.uk/cross-study-data-guides/cognitive-measures-guide/bcs70-cognition/bcs70-age-5-human-figure-drawing/

*Complete a Profile Test
*https://www.closer.ac.uk/cross-study-data-guides/cognitive-measures-guide/bcs70-cognition/bcs70-age-5-complete-a-profile-test/


hist f118 
hist f120
replace f120=. if f120<=-4
hist f120

hist f121
replace f121=. if f121<-4

hist f122
replace f122=. if f122<-4 

*Schonell reading 
*https://www.closer.ac.uk/cross-study-data-guides/cognitive-measures-guide/bcs70-cognition/bcs70-age-5-schonell-reading-test/

hist f100
tab f100
replace f100=. if f099==-3
replace f100=0 if f100<0
sum f100


local list f100 f118  f120 f121 f122
gen BCSID=bcsid
keep bcsid BCSID  `list'

rename  f100 cog5_1
lab var cog5_1 "Schonell reading score, age 5"
rename f122 cog5_2
rename f118 cog5_3
rename f121 cog5_4
*Standardised EPTV
rename f120 cog5_5

sum cog*
corr cog* 

replace cog5_3=. if cog5_3<0

save "$data\cognitivescores_age5.dta" , replace

******************************
*Cognitive measures at age 10
******************************
use "$rawdata\bcs3derived.dta", clear
drop if BCSID==""
gen bcsid=BCSID

*Edinburgh Reading Test (Shortened Version)
replace BD3READ=. if BD3RDAGE<0
rename BD3READ cog10_1
lab var cog10_1 "Standardised Edinburgh Reading Test score, age 10"

*Friendly Maths Test
rename BD3MATHS cog10_2
replace cog10_2=. if cog10_2<1
labe var cog10_2 "Friendly Maths Test score, age 10"

drop if cog10_1==. & cog10_2==.

merge 1:1 bcsid using "$rawdata\sn3723.dta" 
drop _merge

replace bcsid=BCSID if bcsid==""
replace BCSID=bcsid if BCSID==""

*Spelling Dictation Task
local list  i3815 i3816 i3817 i3818 i3819 i3820 i3821 i3822 i3823 i3824 i3825 i3826 i3827 i3828 i3829 i3830 i3831 i3832 i3833 ///
i3834 i3835 i3836 i3837 i3838 i3839 i3840 i3841 i3842 i3843 i3844 i3845 i3846 i3847 i3848 i3849 i3850 i3851 i3852 i3853 i3854 i3855 i3856 i3857 i3858 i3859 i3860 i3861 i3862 i3863 i3864

gen nonmiss=0
foreach item in `list' {
replace nonmiss=1 if `item'!=. & `item'>0
replace `item'=0 if `item'!=1 & `item'!=.
}

egen cog10_3=rowtotal(`list')
replace cog10_3=. if nonmiss==0
sum cog10_3
lab var cog10_3 "Spelling Dictation Task, age 10"


*BAS word definitions
local list i3504 i3505 i3506 i3507 i3508 i3509 i3510 i3511 i3512 i3513 i3514 i3515 i3516 i3517 i3518 i3519 i3520 i3521 i3522 i3523 i3524 i3525 i3526 i3527 i3528 i3529 i3530 i3531 i3532 i3533 i3534 i3535 i3536 i3537 i3538 i3539 i3540

cap drop nonmiss
gen nonmiss=0
foreach item in `list' {
replace nonmiss=1 if `item'!=. & `item'>0
replace `item'=0 if `item'!=1 & `item'!=.
}

egen cog10_4=rowtotal(`list')
replace cog10_4=. if nonmiss==0
sum cog10_4
lab var cog10_4 "BAS Word Definitions, age 10"

*BAS word similarities
local list i3575 i3576 i3577 i3578 i3579 i3580 i3581 i3582 i3583 i3584 i3585 i3586 i3587 i3588 i3589 i3590 i3591 i3592 i3593 i3594 i3595 i3596 i3597 i3598 i3599 i3600 i3601 i3602 i3603 i3604 i3605 i3606 i3607 i3608 i3609 i3610 i3611 i3612 i3613 i3614 i3615 i3616


cap drop nonmiss
gen nonmiss=0
local vars
forval item=3575(2)3615 {
local j=`item'+1
replace nonmiss=1 if i`item'!=. & i`item'>0 & i`j'!=. & i`j'>0
gen g`item'=0
replace g`item'=1 if i`item'==1 & i`j'==1 
local vars `vars' g`item'
}

egen cog10_5=rowtotal(`vars')
replace cog10_5=. if nonmiss==0
sum cog10_5
lab var cog10_5 "BAS Word Similarities, age 10"

*BAS Recall of Digits
local list i3541 i3541 i3542 i3543 i3544 i3545 i3546 i3547 i3548 i3549 i3550 i3551 i3552 i3553 i3554 i3555 i3556 i3557 i3558 i3559 i3560 i3561 i3562 i3563 i3564 i3565 i3566 i3567 i3568 i3569 i3570 i3571 i3572 i3573 i3574

cap drop nonmiss
gen nonmiss=0
foreach item in `list' {
replace nonmiss=1 if `item'!=. & `item'>0
replace `item'=0 if `item'!=1 & `item'!=.
}

egen cog10_6=rowtotal(`list')
replace cog10_6=. if nonmiss==0
sum cog10_6
lab var cog10_6 "BAS Recall of Digits, age 10"

*BAS Matrices
local list i3617 i3618 i3619 i3620 i3621 i3622 i3623 i3624 i3625 i3626 i3627 i3628 i3629 i3630 i3631 i3632 i3633 i3634 i3635 i3636 i3637 i3638 i3639 i3640 i3641 i3642 i3643 i3644

cap drop nonmiss
gen nonmiss=0
foreach item in `list' {
replace nonmiss=1 if `item'!=. & `item'>0
replace `item'=0 if `item'!=1 & `item'!=.
}

egen cog10_7=rowtotal(`list')
replace cog10_7=. if nonmiss==0
sum cog10_7
lab var cog10_7 "BAS Matrices, age 10"

*Pictorial Language Comprehension Test
local list1 i8 i9 i10 i11 i12 i13 i14 i15 i16 i17 i18 i19 i20 i21 i22 i23 i24 i25 i26 i27 i28 i29 i30 i31 i32 i33 i34 i35 i36 i37 i38 i39 i40 i41 i42 i43 i44 i45 i46 i47 i48 i49 i50 i51 i52 i53 i54 i55 i56 i57 i58 i59 i60 i61 i62 i66 i67 i68 i69 i70 i71 i72 i73 i74 i75 i76 i77 i78 i79 i80 i81 i82 i83 i84 i85 i86 i87 i88 i89 i90 i91 i92 i93 i94 i95 i96 i97 

cap drop nonmiss
gen nonmiss=0
local plct
foreach item in `list1' {
replace nonmiss=1 if `item'!=. & `item'>=0
gen plct`item'=1 if `item'==0
local plct `plct' plct`item'
}

local list2 i98 i99 i100 i101 i102 i103 i104 i105 i106 i107 i108 i109 i110
foreach item in `list2' {
replace nonmiss=1 if `item'!=. & `item'>0
gen plct`item'=1 if `item'==1
local plct `plct' plct`item'

}

cap drop cog10_8
egen cog10_8=rowtotal(`plct')
replace cog10_8=. if nonmiss==0
sum cog10_8
lab var cog10_8 "Pictorial Language Comprehension Test, age 10"

sum cog10_*
corr cog10_*

keep bcsid BCSID cog10_*
save "$data\cognitivescores_age10.dta" , replace


*************************************
**Cognitive measures at age 16
*************************************

*Arithmetic tests
use "$rawdata\bcs70_16-year_arithmetic_data.dta" , clear
rename mathscore cog16_1
lab var cog16_1 "Arithmetic scores, age 16"
gen BCSID=bcsid
keep BCSID bcsid cog16_1

merge 1:1 BCSID using "$rawdata\bcs1986_reading_matrices.dta" 
drop _merge

*BAS Matrices
rename SCR_M cog16_2
replace cog16_2=. if cog16_2<0
lab var cog16_2 "BAS Matrices, age 16"

*Edinburgh Reading Test scores
rename SCRTOTAL cog16_3
replace cog16_3=. if cog16_3<0
lab var cog16_3 "Edinburgh Reading Test score, age 16"

replace bcsid=BCSID if bcsid==""
replace BCSID=bcsid if BCSID==""

keep bcsid BCSID cog16_*

merge 1:1 bcsid using "$rawdata\bcs7016x.dta"
drop _merge

replace bcsid=BCSID if bcsid==""
replace BCSID=bcsid if BCSID==""

*Spelling
local list c7a1 c7a2 c7a3 c7a4 c7a5 c7a6 c7a7 c7a8 c7a9 c7a10 c7a11 c7a12 c7a13 c7a14 c7a15 c7a16 c7a17 c7a18 c7a19 c7a20 c7a21 c7a22 c7a23 c7a24 c7a25 c7a26 c7a27 c7a28 c7a29 c7a30 c7a31 c7a32 c7a33 c7a34 c7a35 c7a36 c7a37 c7a38 c7a39 c7a40 c7a41 c7a42 c7a43 c7a44 c7a45 c7a46 c7a47 c7a48 c7a49 c7a50 c7a51 c7a52 c7a53 c7a54 c7a55 c7a56 c7a57 c7a58 c7a59 c7a60 c7a61 c7a62 c7a63 c7a64 c7a65 c7a66 c7a67 c7a68 c7a69 c7a70 c7a71 c7a72 c7a73 c7a74 c7a75 c7a76 c7a77 c7a78 c7a79 c7a80 c7a81 c7a82 c7a83 c7a84 c7a85 c7a86 c7a87 c7a88 c7a89 c7a90 c7a91 c7a92 c7a93 c7a94 c7a95 c7a96 c7a97 c7a98 c7a99 c7a100 c7b1 c7b2 c7b3 c7b4 c7b5 c7b6 c7b7 c7b8 c7b9 c7b10 c7b11 c7b12 c7b13 c7b14 c7b15 c7b16 c7b17 c7b18 c7b19 c7b20 c7b21 c7b22 c7b23 c7b24 c7b25 c7b26 c7b27 c7b28 c7b29 c7b30 c7b31 c7b32 c7b33 c7b34 c7b35 c7b36 c7b37 c7b38 c7b39 c7b40 c7b41 c7b42 c7b43 c7b44 c7b45 c7b46 c7b47 c7b48 c7b49 c7b50 c7b51 c7b52 c7b53 c7b54 c7b55 c7b56 c7b57 c7b58 c7b59 c7b60 c7b61 c7b62 c7b63 c7b64 c7b65 c7b66 c7b67 c7b68 c7b69 c7b70 c7b71 c7b72 c7b73 c7b74 c7b75 c7b76 c7b77 c7b78 c7b79 c7b80 c7b81 c7b82 c7b83 c7b84 c7b85 c7b86 c7b87 c7b88 c7b89 c7b90 c7b91 c7b92 c7b93 c7b94 c7b95 c7b96 c7b97 c7b98 c7b99 c7b100

cap drop nonmiss
gen nonmiss=0
local spelling 
foreach item in `list' {
replace nonmiss=1 if `item'!=. & `item'>0
gen spelling`item'=1 if `item'==1
local spelling `spelling' spelling`item'
}

cap drop cog16_4
egen cog16_4=rowtotal(`spelling')
replace cog16_4=. if nonmiss==0
sum cog16_4
lab var cog16_4 "Spelling, age 16"

keep bcsid BCSID cog16_*

*Vocabulary
merge 1:1 BCSID using "$rawdata\bcs4derived.dta" 
drop _merge

replace bcsid=BCSID if bcsid==""
replace BCSID=bcsid if BCSID==""

rename BD4READ cog16_5
replace cog16_5=. if BD4RDAGE<0
lab var cog16_5 "Standardised Vocabulary Test score, age 16"

keep bcsid BCSID cog16_*
save "$data\cognitivescores_age16.dta" , replace


*Educational attainment and school type at age 16
use "$rawdata\bcs4derived.dta" , clear

*school type
/*label list BD4STYPE
BD4STYPE:
          -1 Unknown
           1 Comprehensive
           2 Grammar
           3 Secondary Modern/Technical
           4 Independent Private
           5 LEA Special
           6 Independent Special
           7 Other
           8 Scottish LEA
*/

/*. tab BD4STYPE

    DV: School Type Age 16 |
      (derived from STYPE, |
  B9SC16TP and 1986 School |
                   Census) |      Freq.     Percent        Cum.
---------------------------+-----------------------------------
                   Unknown |      1,657       14.27       14.27
             Comprehensive |      7,983       68.73       83.00
                   Grammar |        338        2.91       85.91
Secondary Modern/Technical |        613        5.28       91.18
       Independent Private |        522        4.49       95.68
               LEA Special |        108        0.93       96.61
       Independent Special |         17        0.15       96.75
                     Other |         59        0.51       97.26
              Scottish LEA |        318        2.74      100.00
---------------------------+-----------------------------------
                     Total |     11,615      100.00
					 
Reading test score are high in
Grammar and Independent Private					 
*/

/*Sullivan et all:
comprehensive
gramnmar
secondary modern
private 
for boys: Tatler public schools vs other private
*/

gen private_grammar=0
replace private_grammar=99 if BD4STYPE==-1
replace private_grammar=1 if BD4STYPE==2 | BD4STYPE==4

keep BCSID private_grammar
gen bcsid=BCSID
merge 1:1 bcsid using "$rawdata\bcs7016x.dta"
drop _merge

*Math grades in O level or CSE or equivalent
gen math_O_CSE=0 if  t2c2_1>0 | t2c1_1>0
forval i=1/6 {
replace math_O_CSE=`i' if (t2c2_2==`i' | t2c1_2==`i') & (math_O_CSE==0 | math_O_CSE==.)
}

tab math_O_CSE, m

replace math_O_CSE=99 if math_O_CSE==. | math_O_CSE<0
tab math_O_CSE, m

lab def math_O_CSE ///
0 "No math O/CSE" ///
1 "Grade A/1" ///
2 "Grade B/2" ///
3 "Grade C/3" ///
4 "Grade D/4" ///
5 "Grade E/5" ///
6 "Failed" ///
99 "No info"

lab val math_O_CSE math_O_CSE

keep bcsid BCSID private_grammar math_O_CSE

replace bcsid=BCSID if bcsid==""
replace BCSID=bcsid if BCSID==""

merge 1:1 bcsid using "$rawdata\bcs96x.dta" 
drop _merge

gen A_level=0
replace A_level=1 if  b960165==11

replace bcsid=BCSID if bcsid==""
replace BCSID=bcsid if BCSID==""

keep bcsid BCSID private_grammar math_O_CSE A_level

save "$data\education_age16_26.dta" , replace


**************************
*Data on work experience
**************************
use "$rawdata\bcs70_activity_histories_eul.dta" , clear

*keep paid employment spells only

order BCSID ACTNUM NUMACTS JSTYR JSTMTH JENDYR JENDMTH JSTCMC JENDCMC JDUR JACTIV 
keep BCSID JACTIV CMSEX ACTNUM NUMACTS JSTYR JSTMTH JENDYR JENDMTH JSTCMC JENDCMC JDUR JACTIV 

***************************
*Employed
/****************************
label list JACTIV
JACTIV:
          -9 Refused
          -8 Don't know/ not enough info.
          -1 N/a no activities reported for CM
		  
           1 F/t paid employee (30+ hrs)
           2 P/t paid employee (lt 30 hrs)
           3 F/t self-employed
           4 P/t self-employed
           5 Employed, not known if FT/PT
           6 Self-employed, not known if FT/PT
           
           8 f/t not know if emp or s/e
           9 p/t not know if emp or s/e
          10 Work but not known if ft/pt or emp/se
		  
		  
          11 Unemployed seeking work
		  
		  * edu
          12 F/t education
          13 Part-time education
          14 Government training scheme
		  
		  
		  * other, inactive
          15 Temporarily sick/disabled
          16 Permanently sick/disabled
          17 Sick/ disabled not known if perm/temp
          18 Looking after home/family
		  7 Employed, but unpaid
		  
		  *
          19 Wholly retired
          20 Voluntary work
          21 Maternity leave
          22 Travelling/Extended holiday
          97 Other

*/

* employed (= full-time + part-time + non-defined time)
gen employed=1 if JACTIV>=1 & JACTIV<=10 & JACTIV!=7

* full-time employed
gen ftemployed=1 if JACTIV==1 | JACTIV==3 | JACTIV==8


*employment probability over time
keep BCSID CMSEX employed ftemployed JACTIV ACTNUM NUMACTS JSTYR JSTMTH JSTCMC JENDYR JENDMTH JENDCMC 
*keeping only labour market spells
keep if employed==1
replace JENDCMC=1404 if JENDCMC==-6
replace JENDMTH=12 if JENDMTH==-6

drop if JSTYR>2016

*geeting months between April 1986 and Dec 2016
forval i=1036/1404 {
    
gen emp`i'=0
replace emp`i'=1 if `i'>=JSTCMC & JENDCMC>=`i' & employed==1

gen ftemp`i'=0
replace ftemp`i'=1 if `i'>=JSTCMC & JENDCMC>=`i' & ftemployed==1

}



forval i=1036/1404 {

bysort BCSID: egen mean_emp`i'=mean(emp`i')
replace mean_emp`i'=1 if mean_emp`i'>0 & mean_emp`i'<1
replace emp`i'= mean_emp`i'
drop  mean_emp`i'

bysort BCSID: egen mean_ftemp`i'=mean(ftemp`i')
replace mean_ftemp`i'=1 if mean_ftemp`i'>0 & mean_ftemp`i'<1
replace ftemp`i'= mean_ftemp`i'
drop  mean_ftemp`i'

}

*Ftemp: 0.5
forval i=1036/1404 {
replace emp`i'=0.5 if emp`i'==1 & ftemp`i'==0
}


keep BCSID CMSEX emp1* 
duplicates drop
duplicates report BCSID

preserve

collapse (sum) emp*  , by(CMSEX ) 
reshape long emp, i(CMSEX)  j(month)


lab def month 1036 "16" ///
1096	"21" ///
1156	"26" ///
1216	"31" ///
1276	"36" ///
1336	"41" ///
1396	"46"

lab val month month

twoway (line emp month if CMSEX==1) (line emp month if CMSEX==2), ///
legend(label(1 "Men") label(2 "Women")) ytitle("No. of months in employment, FT equivalents") ///
xtitle("Age") xlabel(1036(60)1404, val)


restore

*dec 1996: 1164
*dec 2004: 1260
*dec 2012: 1356
*dec 2016: 1404

order BCSID emp1* 

egen emp_42=rowtotal(emp1036-emp1356)

keep BCSID  emp_42

save "$data\OAR_emp_history.dta", replace

cap log close
