
*****************
***Regressions***
*****************
cap log close 
log using "logs\6_OAR_wage_paper_models", replace


global outcome log_hourlypay_42

use "$data\OAR_wage_paper_database_FTemployed.dta", clear

*setting the sample
global controls0 i.region SES m_quali i.ethnicity 
global channels1 $controls0 i.private_grammar i.math_O_CSE i.A_level
global channels2 $channels1 STEM LEM other elite_uni 
global channels3 $channels2 i.SOC2000_2digit i.private_sector emp_42
global channels4 $channels3 partner_age42  child2 child3

global outreg  dec(3) noomitted label noni  ///
drop(1.region 2.region 3.region 4.region 5.region 6.region 7.region 8.region 9.region 10.region 11.region 99.region ///
1.ethnicity 2.ethnicity 3.ethnicity 4.ethnicity 5.ethnicity 6.ethnicity 7.ethnicity 8.ethnicity 99.ethnicity ///
SES m_quali 1.private_grammar 2.private_grammar 99.private_grammar  ///
1.math_O_CSE 2.math_O_CSE 3.math_O_CSE 4.math_O_CSE 5.math_O_CSE 6.math_O_CSE 7.math_O_CSE 99.math_O_CSE ///
A_level) nonotes word excel  alpha(0.001, 0.01, 0.05)

****************************
*Table 1: The gender wage gap
****************************
global model table1
global sort  female overconfidence_score cognitive_cfa

reg  $outcome female , vce(robust) 

outreg2 using "results\\${model}.doc" ,  replace ctitle(Model 1) $outreg sortvar($sort )

reg $outcome female overconfidence_score ,  vce(robust) 
mat A2=(2,1,e(N),_b[female],_se[female],.,.,.,.)

outreg2 using "results\\${model}.doc",  ctitle(Model 2)  $outreg 

********************************************************************
*testing the difference of the two female coeff of Model 1 and Model 2
********************************************************************
/*reg  $outcome female 
est store m1 
reg $outcome female ${right`i'} 
est store m2

suest m1 m2 , vce(robust)
test [m1_mean=m2_mean], common
*/


reg $outcome female  overconfidence_score cognitive_cfa ,  vce(robust) 
outreg2 using "results\\${model}.doc" ,  ctitle(Model 3)  $outreg  

reg $outcome female overconfidence_score cognitive_cfa $controls0 ,  vce(robust) 
outreg2 using "results\\${model}.doc", ctitle(Model 4A)  $outreg addtext("Social background, Yes") 


global sort   female overconfidence_score cognitive_cfa conf_irt underconfident overconfident 

reg $outcome female conf_irt cognitive_cfa $controls0 ,  vce(robust) 
outreg2 using "results\\${model}.doc", ctitle(Model 4B )  $outreg addtext("Social background, Yes") 

reg $outcome female underconfident overconfident  cognitive_cfa $controls0 ,  vce(robust) 
outreg2 using "results\\${model}.doc", ctitle(Model 4C)  $outreg addtext("Social background, Yes") 


*****************************
*Quantile regressions - Table A5
*****************************

global model tableA5

global right underconfident overconfident

sqreg $outcome female  cognitive_cfa $controls0 ,  quantiles(0.25) 
outreg2 using "results\\${model}_sqreg.doc" ,  replace $outreg ctitle(q0.25)
sqreg $outcome female ${right} cognitive_cfa $controls0 ,  quantiles(0.25) 
outreg2 using "results\\${model}_sqreg.doc" ,   $outreg ctitle(q0.25)

sqreg $outcome female  cognitive_cfa $controls0 ,  quantiles(0.50) 
outreg2 using "results\\${model}_sqreg.doc" ,   $outreg ctitle(q0.50)
sqreg $outcome female ${right} cognitive_cfa $controls0 ,  quantiles(0.50) 
outreg2 using "results\\${model}_sqreg.doc" ,   $outreg ctitle(q0.50)

sqreg $outcome female  cognitive_cfa $controls0 ,  quantiles(0.75) 
outreg2 using "results\\${model}_sqreg.doc" ,   $outreg ctitle(q0.75)
sqreg $outcome female ${right} cognitive_cfa $controls0 ,  quantiles(0.75) 
outreg2 using "results\\${model}_sqreg.doc" ,   $outreg ctitle(q0.75)



****************************
*Table A6 and A7: Returns to overconfidence by gender
****************************

global outreg dec(3) tex(fragment) noomitted label noni  ///
nonotes word alpha(0.001, 0.01, 0.05) keep(overconfident underconfident cognitive_cfa)

global model0 TableA7
global model1 TableA8

forval i=0/1 {
	
reg  $outcome overconfident underconfident if female==`i', vce(robust) 
outreg2 using "results\\${model`i'}.doc" ,  ctitle(Model 1)  $outreg replace

reg $outcome overconfident underconfident cognitive_cfa if female==`i',  vce(robust) 
outreg2 using "results\\${model`i'}.doc" ,  ctitle(Model 2)  $outreg 

reg $outcome overconfident underconfident cognitive_cfa $controls0 if female==`i',  vce(robust) 
outreg2 using "results\\${model`i'}.doc" ,  ctitle(Model 3)  $outreg ///
addtext(Background, Yes) 


reg $outcome overconfident underconfident cognitive_cfa $channels1 if female==`i',  vce(robust) 
outreg2 using "results\\${model`i'}.doc" , ctitle(Model 4)  $outreg ///
addtext(Background, Yes,Pre-uni education, Yes) 


reg $outcome overconfident underconfident cognitive_cfa $channels2 if female==`i',  vce(robust) 
outreg2 using "results\\${model`i'}.doc" , ctitle(Model 5)  $outreg ///
addtext(Background, Yes,Pre-uni education, Yes,Graduation, Yes) 

reg $outcome  overconfident underconfident cognitive_cfa $channels3 if female==`i',  vce(robust) 
outreg2 using "results\\${model`i'}.doc" , ctitle(Model 6)  $outreg ///
addtext(Background, Yes,Pre-uni education, Yes,Graduation, Yes,Occupation codes, Yes ) 


reg $outcome overconfident underconfident cognitive_cfa $channels4 if female==`i',  vce(robust) 
outreg2 using "results\\${model`i'}.doc" , ctitle(Model 7)  $outreg ///
addtext(Background, Yes , Pre-uni education, Yes,Graduation, Yes,Occupation codes, Yes,Partner and children, Yes ) 

}

cap log close





