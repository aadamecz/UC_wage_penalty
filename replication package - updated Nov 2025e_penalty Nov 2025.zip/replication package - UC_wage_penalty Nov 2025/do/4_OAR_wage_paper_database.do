cap log close
log using "logs\4_OAR_wage_paper_database.smcl", replace


*******************************
*Age 0 and 5: family background
*******************************
use "$rawdata\bcs1derived.dta", clear
merge 1:1 BCSID using "$rawdata\bcs2derived.dta" 
drop _merge


gen first_born=0
replace first_born=1 if BD1AGEFB==BD1MAGE & BD1MAGE>0
replace first_born=99 if BD1AGEFB < 0
replace first_born=99 if BD1MAGE < 0
lab var first_born "First-born child"

lab def first_born ///
1 "Yes" ///
0 "No" ///
99 "Missing" ///


*parental social class from age 0 and age 5
tab BD1PSOC BD2SOC, m

/*label list BD1PSOC
label list  VAR00004
VAR00004:
          -1 nk/ns
           1 single parent - not working
           2 Other category
           3 V unskilled
           4 IV partly-skilled
           5 III manual
           6 III non manual
           7 II managerial and Technical
           8 I professional
*/


label list BD2SOC
/*
BD2SOC:
          -1 info missing
           0 student/voluntary work
           1 V unskilled
           2 IV partly-skilled
           3 III manual
           4 III non manual
           5 II managerial and Technical
           6 I professional
*/

lab def social_class ///
1 "Not working, other or missing" ///
2 "V unskilled" ///
3 "IV partly-skilled" ///
4 "III manual" ///
5 "III non manual" ///
6 "II managerial and technical" ///
7 "I professional" 

recode BD2SOC (-1 0=1) (1=2) (2=3) (3=4) (4=5) (5=6) (5=7)
recode BD1PSOC (-1 1 2=1) (3=2) (4=3) (5=4) (6=5) (7=6) (8=7)
rename BD1PSOC social_class
lab val social_class social_class
lab var social_class "Parental social class"

tab social_class, m
*adding missing values from age 5
replace social_class=BD2SOC if social_class==. 

gen SES=0 if (social_class>=1 & social_class<=4) 
replace SES=1 if social_class>=5 & social_class<=7

tab social_class SES, m

*mothers age in 1970
replace BD1MAGE=. if BD1MAGE<0

*mothers year of birth
gen myob=1970-BD1MAGE
lab var myob "Mother's year of birth"
tab myob, m

**********************************
*Maternal characteristics at age 0
**********************************
gen bcsid=BCSID
merge 1:1 bcsid using "$rawdata\bcs7072a.dta" 
drop _merge

replace bcsid=BCSID if bcsid==""
replace BCSID=bcsid if BCSID==""

gen female_0=0 if a0255==1
replace female_0=1 if a0255==2

gen mage_education=a0009 if a0009>0
lab var mage_education "Mother's age when completing education"

gen fage_education=a0010 if a0010>0
lab var fage_education "Father's age when completing education"

gen mother_employed_age0=0
replace mother_employed_age0=1 if a0019==1
lab var mother_employed_age0 "Mother employed at age 0"

gen mother_married_age0=0
replace  mother_married_age0=1 if a0012==2
lab var mother_married_age0 "Mother married at age 0"

gen premarital_conception=0 if a0012a>=0
replace premarital_conception=1 if a0012a==1
lab var premarital_conception "Premarital conception"

gen care_athome_age0=0 if a0020>0
replace care_athome_age0=1 if a0020==1
lab var care_athome_age0 "Childcare at home for other children at age 0"


**********************************
*Maternal characteristics at age 5
**********************************
merge 1:1 bcsid using "$rawdata\f699a.dta" 
drop _merge

replace bcsid=BCSID if bcsid==""
replace BCSID=bcsid if BCSID==""

gen female_5=0 if d003==1
replace female_5=1 if d003==2

*mothers age in 1975
merge 1:1 bcsid using "$rawdata\f699b.dta"
drop _merge

replace bcsid=BCSID if bcsid==""
replace BCSID=bcsid if BCSID==""

replace e008=. if e008<0
replace myob=1975-e008 if myob==.
tab myob, m

rename BD1REGN region
lab var region "Region at birth"
replace region=99 if region==. | region<0

lab def region ///
1 "North" ///
2 "Yorks and Humberside" ///
3 "East Midlands" ///
4 "East Anglia" ///
5 "South East" ///
6 "South West" ///
7 "West Midlands" ///
8 "North West" ///
9 "Wales" ///
10 "Scotland" ///
11 "Northern Ireland" ///
12 "Overseas" ///
99 "Region is missing"

lab val region region

gen only_child_inHH_age5 = 0
replace only_child_inHH_age5 = 99 if (e006==-1 | e007==-1)
replace only_child_inHH_age5 = 1 if (e006==0 & e007==0)
lab var only_child_inHH_age5 "Only child in HH, age5"


*gen no_of_childreninHH_age5= 0,1,2,3+ (de nem missing)
gen no_of_childreninHH_age5 = e006 + e007 + 1
replace no_of_childreninHH_age5 = 99 if (e006==-1 | e007==-1)

lab var no_of_childreninHH_age5 "Number of children in household, age 5"
lab def no_of_childreninHH ///
0 "0" ///
1 "1" ///
2 "2" ///
3 "3 or more" ///
99 "data missing"
lab val no_of_childreninHH_age5 no_of_childreninHH

*number of siblings
gen no_of_siblings = no_of_childreninHH_age5 - 1 if no_of_childreninHH_age5 != 99
replace no_of_siblings = 99 if no_of_childreninHH_age5 == 99
replace no_of_siblings = 3 if (no_of_siblings > 2 & no_of_siblings < 99)
lab var no_of_siblings "Number of siblings at age 5"
lab val no_of_siblings no_of_childreninHH

*mother works at age 5
gen mother_employed_age5=0 if e205>0 & e205!=.
replace mother_employed_age5=1 if e205>1 & e205!=.
lab var mother_employed_age5 "Mother employed at age 5"


rename a0278 birthweight
sum birthweight if d003==1
scalar suly0=r(mean)

sum birthweight if d003==2
scalar suly1=r(mean)

replace birthweight=suly0 if (birthweight<0 | birthweight==.) & d003==1
replace birthweight=suly1 if (birthweight<0 | birthweight==.) & d003==2

gen low_bw=0
replace low_bw=1 if birthweight<2500
lab var low_bw "Low birthweight"

*Mean imputation of myob
gen myob_imp=0
replace myob_imp=1 if myob==.

sum myob
replace myob=r(mean) if myob==.

global age0 bcsid BCSID region myob* mother_employed_age0 premarital_conception  mage_education SES first_born mother_married_age0 social_class a0255 a0053 female*

global age5 no_of_siblings only_child_inHH_age5 d003 low_bw e014a no_of_childreninHH_age5  e245 e189a female*

keep $age0 $age5 

save "$data\background.dta", replace

******************************
*Age 10: self-assessed ability
******************************
merge  1:1 bcsid using   "$rawdata\sn3723.dta" 
drop if _merge==2
drop _merge

replace bcsid=BCSID if bcsid==""
replace BCSID=bcsid if BCSID==""

*good at math
tab k018, m
gen good_at_math_age10=.
replace good_at_math_age10=1 if k018==2  /*no*/
replace good_at_math_age10=2 if k018==3 /*don't know*/
replace good_at_math_age10=3 if k018==1 /*yes*/
lab var good_at_math_age10 "Good at math, age 10"

lab def lgood ///
1 "Not good" ///
2 "Don't know" ///
3 "Good" 
lab val good_at_math_age10 lgood

*good at spelling
tab k081, m

gen good_at_spelling_age10=.
replace good_at_spelling_age10=1 if k081==2  /*no*/
replace good_at_spelling_age10=2 if k081==3 /*don't know*/
replace good_at_spelling_age10=3 if k081==1 /*yes*/
lab var good_at_spelling_age10 "Good at spelling, age 10"
lab val good_at_spelling_age10 lgood

*ethnicity
codebook a12_1
rename a12_1 ethnicity
replace ethnicity=99 if ethnicity==.

lab def ethnicity ///
1 "English, etc" ///
2 "Irish" ///
3 "Other European" ///
4 "West Indian" ///
5 "Indian" ///
6 "Pakistani" ///
7 "Bangladeshi" ///
8 "Other" ///
99 "Ethnicity is missing"

lab val ethnicity ethnicity

keep bcsid BCSID good_at_math_age10 good_at_spelling_age10 sex10 ethnicity social_class region SES c1_* e189a 

************************
*Age 16: self-assessed ability
************************
merge 1:1 bcsid using "$rawdata\bcs7016x.dta"
drop if _merge==2
drop _merge 

replace bcsid=BCSID if bcsid==""
replace BCSID=bcsid if BCSID==""

tab c5h10, m

/*

    I am not very |
   good at school |      Freq.     Percent        Cum.
------------------+-----------------------------------
       Not stated |        505        4.67        4.67
 No questionnaire |      5,215       48.21       52.88
Applies very much |        317        2.93       55.81
 Applies somewhat |      1,800       16.64       72.45
   Does not apply |      2,980       27.55      100.00
------------------+-----------------------------------
            Total |     10,817      100.00

*/

*good at school
gen gas_cat=1 if c5h10==1
replace gas_cat=2 if c5h10==2
replace gas_cat=3 if c5h10==3

lab def gas_cat 1 "Not very good at school"  2 "Somewhat good at school" 3 "Good at school"
lab val gas_cat gas_cat

tab gas_cat c5h10, m

tab gas_cat, gen(goodatschool)
lab var goodatschool1 "Not very good at school"
lab var goodatschool2 "Somewhat good at school"
lab var goodatschool3 "Good at school"

tab goodatschool3 gas_cat, m


*decoding missing values
local list c5h1 c5h2 c5h3 c5h4 c5h5 c5h6 c5h7 c5h8 c5h9 c5h10 c5h11 c5h12 c5h13 c5h14 c5h15 c5h16 c5h17 c5h18 c5h19 c5h20 c5h21 c5h22 c5h23 c5h24 c5h25 c5h26 c5h27

sum `list'
foreach item in `list' {
replace `item'=. if `item'<0
}


*clever
tab c5h6, m
/*
      I am clever |      Freq.     Percent        Cum.
------------------+-----------------------------------
Applies very much |      1,052        9.73        9.73
 Applies somewhat |      3,565       32.96       42.68
   Does not apply |        555        5.13       47.81
                . |      5,645       52.19      100.00
------------------+-----------------------------------
            Total |     10,817      100.00
*/


gen clever_cat=1 if c5h6==3
replace clever_cat=2 if c5h6==2
replace clever_cat=3 if c5h6==1

tab c5h6 clever_cat, m

tab clever_cat, gen(clever)
lab var clever1 "Not clever"
lab var clever2 "Somewhat clever"
lab var clever3 "Clever"

sum clever*

*good at exams
tab c5h21, m
/*
. *good at exams
. tab c5h21, m

     I am good at |
            exams |      Freq.     Percent        Cum.
------------------+-----------------------------------
Applies very much |        814        7.53        7.53
 Applies somewhat |      3,235       29.91       37.43
   Does not apply |      1,118       10.34       47.77
                . |      5,650       52.23      100.00
------------------+-----------------------------------
            Total |     10,817      100.00
*/

gen good_at_exams=1 if c5h21==3
replace good_at_exams=2 if c5h21==2
replace good_at_exams=3 if c5h21==1

tab good_at_exams c5h21, m
tab good_at_exams, gen(goodatexams)

lab var goodatexams1 "Not good at exams"
lab var goodatexams2 "Somewhat good at exams"
lab var goodatexams3 "Good at exams"


*Are you good at spelling?
tab c5l6, m
/*
 Are you good at |
       spelling? |      Freq.     Percent        Cum.
-----------------+-----------------------------------
      Not stated |        493        4.56        4.56
No questionnaire |      5,215       48.21       52.77
             Yes |      2,799       25.88       78.64
              No |      1,303       12.05       90.69
      Don't know |      1,007        9.31      100.00
-----------------+-----------------------------------
           Total |     10,817      100.00

*/
gen good_at_spelling_age16=.
replace good_at_spelling_age16=1 if c5l6==2  /*no*/
replace good_at_spelling_age16=2 if c5l6==3 /*don't know*/
replace good_at_spelling_age16=3 if c5l6==1 /*yes*/
lab var good_at_spelling_age16 "Good at spelling, age 10"
lab val good_at_spelling_age16 lgood

label list lgood

*Are you good at mathematics? 
tab c5l24, m
gen good_at_math_age16=.
replace good_at_math_age16=1 if c5l24==2  /*no*/
replace good_at_math_age16=2 if c5l24==3 /*don't know*/
replace good_at_math_age16=3 if c5l24==1 /*yes*/
lab var good_at_math_age16 "Good at math, age 16"
lab val good_at_math_age16 lgood


*Merging data on objective cognitive ability
merge 1:1 bcsid using "$data\cognitivescores_age5.dta"
drop if _merge==2
drop _merge

replace bcsid=BCSID if bcsid==""
replace BCSID=bcsid if BCSID==""

merge 1:1 bcsid using "$data\cognitivescores_age10.dta"
drop if _merge==2
drop _merge

replace bcsid=BCSID if bcsid==""
replace BCSID=bcsid if BCSID==""

merge 1:1 bcsid using "$data\cognitivescores_age16.dta"
drop if _merge==2
drop _merge

replace bcsid=BCSID if bcsid==""
replace BCSID=bcsid if BCSID==""

*Merging data on education
merge 1:1 bcsid using "$data\education_age16_26.dta"
drop if _merge==2
drop _merge

replace bcsid=BCSID if bcsid==""
replace BCSID=bcsid if BCSID==""

*************************
*Merging data on outcomes from age 42
*************************
merge 1:1 BCSID using  "$data\outcomes42.dta"
*We only keep those with age 42 data and background data
keep if _merge==3
drop _merge

replace BCSID=bcsid if BCSID=="" & bcsid!=""
replace bcsid=BCSID if BCSID!="" & bcsid==""

*************************************
*Measures of objective cognitive skills - standardization and dropping non-response
****************************************
sum cog5_* cog10_* cog16_*
corr cog5_* cog10_* cog16_*

local list cog5_1 cog5_3 cog5_5 cog5_4 cog5_2 

*we use the variable "miss" to drop observations who have none of these measures
gen miss=1
foreach item in `list' {
sum `item'
gen std`item'=(`item'-r(mean))/r(sd)
replace miss=0 if `item'!=.
}


local list cog10_1 cog10_2 cog10_3 cog10_4 cog10_5 cog10_6 cog10_7 cog10_8 
foreach item in `list' {
sum `item'
gen std`item'=(`item'-r(mean))/r(sd)
replace miss=0 if `item'!=.
}

local list cog16_1 cog16_2 cog16_3 cog16_4 cog16_5
foreach item in `list' {
sum `item'
gen std`item'=(`item'-r(mean))/r(sd)
replace miss=0 if `item'!=.
}

drop if miss==1 
drop miss

****************************************
*Measures of self-assessed ability - dropping non-response
****************************************
local list clever_cat good_at_exams gas_cat good_at_math_age16 good_at_spelling_age16
gen miss=1
foreach item in `list' {
sum `item'
replace miss=0 if `item'!=.
}


local list good_at_math_age10 good_at_spelling_age10
foreach item in `list' {
sum `item'
replace miss=0 if `item'!=.
}


drop if miss==1 
drop miss


******************************
*Creating the objective cognitive ability measure
******************************* 
sum std*
sem (std* <- cognitive_cfa), latent(cognitive_cfa) method(mlmv)
predict cognitive_cfa, latent
sum cognitive_cfa
replace cognitive_cfa=(cognitive_cfa-r(mean))/r(sd)

sum cognitive_cfa cog5_* cog10_* cog16_*
corr cognitive_cfa cog5_* cog10_* cog16_*

gen high_cog=0
replace high_cog=1 if cognitive_cfa>=0 & cognitive_cfa!=.
lab var high_cog "High cognitive skills"

xtile cognitive_cat=cognitive_cfa, n(5)

******************************
*Creating the subjective cognitive ability measure
******************************* 
global list2 clever_cat good_at_exams gas_cat good_at_math_age10  good_at_math_age16 good_at_spelling_age10 good_at_spelling_age16 
sum $list2

alpha $list2 , item /*alpha=TBA*/

factor  $list2 

/*first factor: good in everything 
*second: good at spelling but not at mathematics 
*third: good at math but not at spelling 
*/

*IRT
irt grm $list2
predict conf_irt, latent 
lab var conf_irt "Self-assessed ability"

******************************
*Overconfidence measures
******************************
*1. Main measure: Residual score using percentile ranks (the higher the rank, the higher the skill)
xtile cog_rank=cognitive_cfa, n(100)
xtile asc_rank=conf_irt, n(100)

reg asc_rank cog_rank
predict asc_rank_pred , xb
gen overconfidence_score=asc_rank-asc_rank_pred

sum overconfidence_score
replace overconfidence_score=(overconfidence_score-r(mean))/r(sd)
hist overconfidence_score
lab var overconfidence_score "Overconfidence score"

*female
cap drop female
gen female=0 if sex10!=. | sex86!=.
replace female=1 if sex10==2 | sex86==2
lab var female "Female"
tab female, m

gen f_overconfidence_score=female*overconfidence_score
lab var f_overconfidence_score "Female*overconfidence score"

*2. Categorical measure: tercials 
xtile oc_tertile=overconfidence_score, n(3)
recode oc_tertile (1=2) (2=1) 
lab var oc_tertile "Overconfidence score tertiles compared to the middle"

label def overconf_tertile ///
1 "Middle" ///
2 "Underconfident" /// 
3 "Overconfident" 

lab val oc_tertile overconf_tertile

gen overconfident=0 if oc_tertile!=.
replace overconfident=1 if oc_tertile==3

gen underconfident=0 if oc_tertile!=.
replace underconfident=1 if oc_tertile==2

gen f_overconfident=female*overconfident
gen f_underconfident=female*underconfident

lab var overconfident "Overconfident"
lab var underconfident "Underconfident"
lab var f_overconfident "Female*overconfident"
lab var f_underconfident "Female*underconfident"

********************************************
****Further control variables and labels****
********************************************
*Mother has a qualification
gen m_quali=0 

replace m_quali=1 if c1_12==1 | c1_13==1 | c1_14==1 | c1_15==1 | c1_16==1 | c1_17==1 | c1_18==1 
replace m_quali=1 if  c1_19>=1 &  c1_19<=9
replace m_quali=1 if  e189a>=2 &  e189a<=8
replace m_quali=1 if t6_1==2 | t6_2==2 | t6_3==2 | t6_4==2 | t6_5==2 | t6_6==2 | t6_7==2
replace m_quali=1 if t6_1==3 | t6_2==3 | t6_3==3 | t6_4==3 | t6_5==3 | t6_6==3 | t6_7==3

lab var m_quali "Mother has a qualification"

replace region=99 if region==.
replace ethnicity=99 if ethnicity==.
replace social_class=99 if social_class==.

tab ethnicity, gen(ethn)
levelsof ethnicity
local i=1
local lab: value label ethnicity
foreach value in `r(levels)' {
	local label: label `lab' `value'
	lab var ethn`i' "`label'"
	local i=`i'+1
	}
	
tab region, gen(reg)
levelsof region
local i=1
local lab: value label region
foreach value in `r(levels)' {
	local label: label `lab' `value'
	lab var reg`i' "`label'"
	local i=`i'+1
	}
	
	
tab RG_subject, gen(rgsub)
levelsof RG_subject
local i=1
local lab: value label RG_subject
foreach value in `r(levels)' {
	local label: label `lab' `value'
	lab var rgsub`i' "`label'"
	local i=`i'+1
	}


lab def private_grammar ///
0 "Public school" 1 "Private or grammar school" ///
99 "School type is missing"

lab val private_grammar private_grammar
	
tab private_grammar, gen(pgram)
levelsof private_grammar
local i=1
local lab: value label private_grammar
foreach value in `r(levels)' {
	local label: label `lab' `value'
	lab var pgram`i' "`label'"
	local i=`i'+1
	}

tab math_O_CSE, m
replace math_O_CSE=99 if math_O_CSE==.
tab math_O_CSE, gen(mathO)
levelsof math_O_CSE
local i=1
local lab: value label math_O_CSE
foreach value in `r(levels)' {
	local label: label `lab' `value'
	lab var mathO`i' "`label'"
	local i=`i'+1
	}
	
lab var SES "High SES parents"
lab var cognitive_cfa "Objective cognitive abilities, STD"
lab var female "Female"


gen elite_uni=0
replace elite_uni=1 if RG==1
lab var elite_uni "Elite university"

/*label list RG_subject
RG_subject:
           0 No degree
           1 STEM
           2 LEM
           3 OSSAH
           4 Other
           5 Combined
           6 Elite STEM
           7 Elite LEM
           8 Elite OSSAH
           9 Elite other
          10 Elite combined
*/


gen uni=0 if RG_subject==0
replace uni=1 if RG_subject==1 | RG_subject==6
replace uni=2 if RG_subject==2 | RG_subject==7
replace uni=3 if (RG_subject>=3 & RG_subject<=5 ) | (RG_subject>=8 & RG_subject<=10)

lab def uni 0 "No degree" 1 "STEM" 2 "LEM" 3 "Other" 
lab val uni uni

*STEM degree
gen STEM=0 if RG_subject!=.
replace STEM=1 if  RG_subject==1 |  RG_subject==6
lab var STEM "STEM degreee"

gen LEM=0 if RG_subject!=.
replace LEM=1 if uni==2
lab var LEM "LEM degree"

gen other=0 if RG_subject!=.
replace other=1 if uni==3
lab var other "Degree of other subject"

replace graduate_age42=0 if RG_subject==0

lab var A_level "A-levels"
tab A_level, m

lab var private_grammar "Private school"

tab private_grammar, m
replace private_grammar=99 if private_grammar==.

lab var clever_cat "Clever"
lab var good_at_exams "Good at exams"
lab var gas_cat "Good at school"
lab var hourlypay_42 "Hourly pay at age 42, GBP"

lab var cognitive_cfa "Objective ability"

tab children_age42, gen(child)

lab var child1 "Has no children"
lab var child2 "Has one child"
lab var child3 "Has at least two children"

*Merging work experience data
merge 1:1 BCSID using "$data\OAR_emp_history.dta", keepusing(emp_42)
drop if _merge==2
drop _merge

lab var emp_42   "Employment experience, age 42"

*standardization of main variables
local list overconfidence_score conf_irt cognitive_cfa
sum `list'

foreach item in `list' {
	sum `item'
	replace `item'=(`item'-r(mean))/r(sd)
}

sum `list'

******************************
*Selection to employment - Robustness test 1 - Table A9 in the Online Appendix
******************************
global controls0 i.region SES m_quali i.ethnicity 
global channels1 $controls0 i.private_grammar i.math_O_CSE i.A_level
global channels2 $channels1 STEM LEM other elite_uni 
global channels3 $channels2 i.SOC2000_2digit i.private_sector emp_42
global channels4 $channels3 partner_age42 child2 child3

global model rob1
global sort  female overconfidence_score cognitive_cfa
global outreg  dec(3) noomitted label noni  ///
drop(1.region 2.region 3.region 4.region 5.region 6.region 7.region 8.region 9.region 10.region 11.region 99.region ///
1.ethnicity 2.ethnicity 3.ethnicity 4.ethnicity 5.ethnicity 6.ethnicity 7.ethnicity 8.ethnicity 99.ethnicity ///
SES m_quali 1.private_grammar 2.private_grammar 99.private_grammar  ///
1.math_O_CSE 2.math_O_CSE 3.math_O_CSE 4.math_O_CSE 5.math_O_CSE 6.math_O_CSE 7.math_O_CSE 99.math_O_CSE ///
A_level) nonotes word excel  alpha(0.001, 0.01, 0.05)


reg employed_age42 overconfidence_score female cognitive_cfa $controls0 , vce(robust)
outreg2 using "results\\${model}.doc" ,  replace ctitle(Employed, M1) $outreg sortvar($sort ) addtext("Sample, Age 42 wave") 

reg employed_age42 overconfident underconfident female cognitive_cfa $controls0 , vce(robust)
outreg2 using "results\\${model}.doc" ,  append ctitle(Employed, M2) $outreg sortvar($sort ) addtext("Sample, Age 42 wave") 


*Selection to FT employment (if employed)
reg emptype421 overconfidence_score female cognitive_cfa $controls0 if employed_age42, vce(robust)
outreg2 using "results\\${model}.doc" ,  append ctitle(FT Employed, M1) $outreg sortvar($sort ) addtext("Sample, Employed at age 42") 

reg emptype421 overconfident underconfident female cognitive_cfa $controls0 if employed_age42, vce(robust)
outreg2 using "results\\${model}.doc" ,  append ctitle(FT Employed, M2) $outreg sortvar($sort ) addtext("Sample, Employed at age 42") 


***************************
*Employed sample
***************************
keep if employed_age42==1

*standardization of main variables
local list overconfidence_score conf_irt cognitive_cfa
sum `list'

foreach item in `list' {
	sum `item'
	replace `item'=(`item'-r(mean))/r(sd)
}

sum `list'


save "$data\OAR_wage_paper_database_employed.dta", replace

*Main models on the employed sample*
reg log_hourlypay_42 female overconfidence_score cognitive_cfa $controls0 ,  vce(robust) 
outreg2 using "results\\${model}.doc" ,  append ctitle(Log hourly wage, M1) $outreg sortvar($sort ) addtext("Sample, Employed at age 42") 

reg log_hourlypay_42 female underconfident overconfident  cognitive_cfa $controls0 ,  vce(robust) 
outreg2 using "results\\${model}.doc" ,  append ctitle(Log hourly wage, M2) $outreg sortvar($sort ) addtext("Sample, Employed at age 42") 


***************************
*Main analytical sample
***************************
sum log_hourlypay_42 overconfidence_score female cognitive_cfa $channels4 if emp_type_age42==1 & log_hourlypay_42!=.
reg log_hourlypay_42 overconfidence_score female cognitive_cfa $channels4 if emp_type_age42==1

count if e(sample)  /*TBA*/

gen main_sample=0
replace main_sample=1 if e(sample)

tab graduate_age42 main_sample, m

***********FT employed sample*************

keep if main_sample==1

*standardization of main variables
local list overconfidence_score conf_irt cognitive_cfa
sum `list'

foreach item in `list' {
	sum `item'
	replace `item'=(`item'-r(mean))/r(sd)
}

sum `list'

save "$data\OAR_wage_paper_database_FTemployed.dta", replace

cap log close